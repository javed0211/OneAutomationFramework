﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OneAutomationFramework.Drivers;
using OneAutomationFramework.Drivers.Appium;
using OneAutomationFramework.Drivers.Selenium;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.iOS;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace OneAutomationFramework.Hooks
{
    [Binding]
    public sealed class SeleniumHooks
    {
        // For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks
        private IAppiumConfiguration _config;
        private static IWebDriver? _driver;
        private static AppiumDriver? _appiumDriver;
        private readonly SeleniumConfiguration? _configuration;
        ScenarioContext _scenarioContext;
        //newcode FlaUI



        public SeleniumHooks(SeleniumDriver driver, ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
            _driver = driver.Current;
        }

        [BeforeScenario]
        public void BeforeScenario()
        {
        }

        //[AfterScenario]
        //public void AfterScenario()
        //{
        //    _driver.Dispose();
        //}
    }
}
