﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace OneAutomationFramework.Drivers
{
    public interface IRestSharpConfiguration
    {
        public string? BaseURL { get; }
        string? projectName { get; }
        public ApiHeader? Header { get;  }

    }
    public class ApiHeader
    {
        public string? ContentType { get; set; }
        public string? Accept { get; set; }
    }

    public class RestSharpConfiguration : IRestSharpConfiguration
    {
        private class SpecFlowActionJson
        {
            [JsonInclude]
            public RestsharpSpecFlowJsonPart RestSharp { get; private set; } = new RestsharpSpecFlowJsonPart();
        }

        private class RestsharpSpecFlowJsonPart
        {
            [JsonInclude]
            public string? BaseURL { get; private set; }

            [JsonInclude]
            public string? projectName { get; private set; }

            [JsonInclude]
            public string? ClientId { get; private set; }

            [JsonInclude]
            public string? SecretId { get; private set; }

            [JsonInclude]
            public string? oAuthURL { get; private set; }

            [JsonInclude]
            public ApiHeader? Header { get; private set; }
        }

        private readonly Lazy<SpecFlowActionJson> _specflowJsonPart;

        private SpecFlowActionJson LoadSpecFlowJson()
        {
            var json = Load();

            if (string.IsNullOrWhiteSpace(json))
            {
                return new SpecFlowActionJson();
            }

            var jsonSerializerOptions = new JsonSerializerOptions()
            {
                PropertyNameCaseInsensitive = true
            };

            jsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());

            var specflowActionConfig = System.Text.Json.JsonSerializer.Deserialize<SpecFlowActionJson>(json, jsonSerializerOptions);

            return specflowActionConfig ?? new SpecFlowActionJson();
        }

        /// <summary>
        /// Provides the configuration details for the RestSharp instance
        /// </summary>
        public RestSharpConfiguration()
        {
            _specflowJsonPart = new Lazy<SpecFlowActionJson>(LoadSpecFlowJson);
        }

        
        public string? BaseURL => _specflowJsonPart.Value.RestSharp.BaseURL;
        public string? projectName => _specflowJsonPart.Value.RestSharp.projectName;

        public string? oAuthURL => _specflowJsonPart.Value.RestSharp.oAuthURL;
        public string? ClientId => _specflowJsonPart.Value.RestSharp.ClientId;
        public string? SecretId => _specflowJsonPart.Value.RestSharp.SecretId;
        public ApiHeader? Header => _specflowJsonPart.Value.RestSharp.Header;

        private string? GetFilePathToConfigurationFile(string configurationFileName)
        {
            if (AppDomain.CurrentDomain.BaseDirectory is not null)
            {
                var specflowJsonFileInAppDomainBaseDirectory =
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, configurationFileName);

                if (File.Exists(specflowJsonFileInAppDomainBaseDirectory))
                {
                    return specflowJsonFileInAppDomainBaseDirectory;
                }

                var specflowJsonFileTwoDirectoriesUp =
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", configurationFileName);

                if (File.Exists(specflowJsonFileTwoDirectoriesUp))
                {
                    return specflowJsonFileTwoDirectoriesUp;
                }
            }

            var specflowJsonFileInCurrentDirectory = Path.Combine(Environment.CurrentDirectory, configurationFileName);

            if (File.Exists(specflowJsonFileInCurrentDirectory))
            {
                return specflowJsonFileInCurrentDirectory;
            }

            return null;
        }

        public string Load()
        {
            var specFlowJsonFilePath = GetFilePathToConfigurationFile("APIConfig.json");

            if (specFlowJsonFilePath != null)
            {
                var content = File.ReadAllText(specFlowJsonFilePath);

                return content;
            }

            return "{}";
        }

        public dynamic LoadJson()
        {
            var specFlowJsonFilePath = GetFilePathToConfigurationFile("APIConfig.json");
            var content = File.ReadAllText(specFlowJsonFilePath);
            return JsonConvert.DeserializeObject(content);

        }
    }
   
}