﻿using RestSharp;
using Newtonsoft.Json.Linq;
using System.Net.Http;
using System;
using OneAutomationFramework.Drivers.Selenium;

namespace OneAutomationFramework.Drivers
{
    public class APIClients
    {
        private readonly RestClient? _client;
        private readonly HttpClient? _httpClient;
        public APIClients(IRestSharpConfiguration configuration)
        {
            _client = new RestClient(configuration.BaseURL);
            _client.AddDefaultHeader("Content-Type", configuration.Header?.ContentType);
            _client.AddDefaultHeader("Accept", configuration.Header?.Accept);
            _httpClient = new HttpClient() { BaseAddress = new Uri(configuration.BaseURL) };
        }

        public RestClient GetRestClient()
        {
            return _client;
        }

        public HttpClient GetHttpClient()
        {
            return _httpClient;
        }
    }
}