﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using TechTalk.SpecFlow;

namespace OneAutomationFramework.Drivers
{
   public class RestSharpDriver
    {
        protected readonly RestClient _client;
        protected readonly HttpClient _httpClient;
        ScenarioContext _scenarioContext;
        private readonly IRestSharpConfiguration _configuration;
        public RestSharpDriver(ScenarioContext scenarioContext, IRestSharpConfiguration configuration)
        {
            _configuration = configuration;
            _client = new APIClients(configuration).GetRestClient();
            _httpClient = new APIClients(configuration).GetHttpClient();
            _scenarioContext = scenarioContext;
        }
    }
}
