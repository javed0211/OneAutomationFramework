﻿using Allure.Commons;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using RestSharp.Authenticators;
using RestSharp.Authenticators.OAuth2;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace OneAutomationFramework.Drivers
{
    public static class RestSharpExtensions
    {


        public static void AddQueryStringParam(this RestRequest request, string paramName, string paramValue)
        {
            request.AddParameter(paramName, paramValue, ParameterType.QueryString);
        }

        public static void CallApi(this RestClient client, string endPoint, Method method, out RestResponse response, string postBody = null)
        {

            var request = new RestRequest(endPoint, method);
            if (postBody != null)
            {
                var requestPath = Path.GetTempFileName();
                File.WriteAllText(requestPath, postBody);
                AllureLifecycle.Instance.AddAttachment("Request", "text/plain", requestPath);
                request.AddBody(postBody);
            }
            response = client.Execute(request);
            var responsePath = Path.GetTempFileName();
            File.WriteAllText(responsePath, response.Content);
            AllureLifecycle.Instance.AddAttachment("Response", "application/json", responsePath);
        }

        public static T CallApi<T>(this RestClient client, string endPoint, Method method, string postBody = null)
        {

            var request = new RestRequest(endPoint, method);
            if (postBody != null)
            {
                var requestPath = Path.GetTempFileName();
                File.WriteAllText(requestPath, postBody);
                AllureLifecycle.Instance.AddAttachment("Request", "text/plain", requestPath);
                request.AddBody(postBody);
            }
            var response = client.Execute(request);
            var responsePath = Path.GetTempFileName();
            File.WriteAllText(responsePath, response.Content);
            AllureLifecycle.Instance.AddAttachment("Response", "application/json", responsePath);
            return JsonConvert.DeserializeObject<T>(response.Content);
        }

        public static T ExecuteReturnType<T>(this RestClient _client, RestRequest request) where T : new()
        {
            var response = _client.Execute<T>(request);

            if (response.ErrorException != null)
            {
                const string errorMsg = "Error retrieving response.  Check inner details for more info.";

                Console.WriteLine($"{errorMsg} {response.ErrorException}");

                throw new ApiException(response.StatusCode, response.ErrorMessage);
            }
            return response.Data;
        }

        public static void ValidateResponse(RestResponse response, HttpStatusCode expectedStatusCode, Dictionary<string, string> expectedHeaders = null, string expectedResponseBody = null)
        {
            Assert.AreEqual(expectedStatusCode, response.StatusCode);
            if (expectedHeaders != null)
            {
                foreach (var header in expectedHeaders)
                {
                    Assert.IsTrue(response.Headers.Any(h => h.Name.Equals(header.Key) && h.Value.Equals(header.Value)));
                }
            }
            if (expectedResponseBody != null)
            {
                Assert.AreEqual(expectedResponseBody, response.Content);
            }
        }

        public static RestResponse ExecuteRequest(this RestClient client, string method, Dictionary<string, string> headers = null, object requestBody = null)
        {
            var callMethod = method.ToLower() switch
            {
                "get" => Method.Get,
                "delete" => Method.Delete,
                "put" => Method.Put,
                "post" => Method.Post,
                _ => throw new ArgumentException($"Invalid HTTP method: {method}")
            };
            var request = new RestRequest();
            request.Method = callMethod;
            if (headers != null)
            {
                foreach (var header in headers)
                {
                    request.AddHeader(header.Key, header.Value);
                }
            }
            if (requestBody != null)
            {
                request.AddJsonBody(requestBody);
            }
            return client.Execute(request);
        }

        #region POST
        public static RestResponse Post(this RestClient client, string resource)
        {
            return Post(client, resource, null);
        }

        public static RestResponse Post(this RestClient client, string resource, object body)
        {
            var request = new RestRequest(resource, Method.Post);

            if (body != null)
            {
                request.AddJsonBody(body);
            }

            return client.Execute(request);
        }

        public static T Post<T>(this RestClient client, string resource)
        {
            return Post<T>(client, resource, null);
        }

        public static T Post<T>(this RestClient client, string resource, object body)
        {
            var request = new RestRequest(resource, Method.Post);

            if (body != null)
            {
                request.AddJsonBody(body);
            }

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<T>(response.Content);
            }
            else
            {
                throw new ApiException(response.StatusCode, response.Content);
            }
        }



        public static RestResponse<T> PostAsync<T>(this RestClient client, string resource, object body, bool deserializeResponse = true)
        {
            var request = new RestRequest(resource, Method.Post);

            if (body != null)
            {
                request.AddJsonBody(body);
            }

            var response = client.Execute<T>(request);

            if (response.IsSuccessStatusCode && deserializeResponse)
            {
                response.Data = JsonConvert.DeserializeObject<T>(response.Content);
            }

            return response;
        }

        public static RestResponse PostAPI(string serviceURI, string accesstoken, string urlSuffix, object data)
        {
            using (WebClient wc = new WebClient())
            {
                var restClient = new RestClient(serviceURI);
                var restRequest = new RestRequest(urlSuffix, Method.Post);
                restRequest.AddHeader(HttpRequestHeader.Authorization.ToString(), "Bearer " + accesstoken);
                restRequest.AddParameter("application/json", data, ParameterType.RequestBody);
                var response = restClient.Execute(restRequest);
                return response;
            }
        }

        public static RestResponse PostAPI(string serviceURI, string urlSuffix, object data)
        {
            using (WebClient wc = new WebClient())
            {
                var restClient = new RestClient(serviceURI);
                var restRequest = new RestRequest(urlSuffix, Method.Post);
                restRequest.AddParameter("application/json", data, ParameterType.RequestBody);
                restRequest.AddHeader("Content-Type", "application/json");
                var response = restClient.Execute(restRequest);
                return response;
            }

        }

        public static RestResponse PostAPI(string serviceURI, string urlSuffix, object data, string userName, string password)
        {
            using (WebClient wc = new WebClient())
            {
                System.Net.ServicePointManager.ServerCertificateValidationCallback +=
                delegate (object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate,
                        System.Security.Cryptography.X509Certificates.X509Chain chain,
                        System.Net.Security.SslPolicyErrors sslPolicyErrors)
                {
                    return true; // **** Always accept
                };

                var restClient = new RestClient(serviceURI);
                var restRequest = new RestRequest(urlSuffix, Method.Post);
                restRequest.AddParameter("application/json", data, ParameterType.RequestBody);
                restRequest.AddHeader("Content-Type", "application/json");
                restRequest.AddHeader("X-OpenIDM-Username", userName);
                restRequest.AddHeader("X-OpenIDM-Password", password);
                var response = restClient.Execute(restRequest);
                return response;
            }

        }


        public static RestResponse PostAPI(string serviceURI, string urlSuffix1, string urlSuffix2, string urlSuffix3, object data)
        {
            string urlSuffix = urlSuffix1 + urlSuffix2 + urlSuffix3;
            using (WebClient wc = new WebClient())
            {
                var restClient = new RestClient(serviceURI);
                var restRequest = new RestRequest(urlSuffix, Method.Post);
                restRequest.AddParameter("application/json", data, ParameterType.RequestBody);
                var response = restClient.Execute(restRequest);
                return response;
            }
        }

        public static RestResponse PostAPI(string serviceURI, string accesstoken, string urlSuffix1, string customerRegistrationId, string urlSuffix2)
        {
            string urlSuffix = urlSuffix1 + customerRegistrationId + urlSuffix2;
            using (WebClient wc = new WebClient())
            {
                var restClient = new RestClient(serviceURI);
                var restRequest = new RestRequest(urlSuffix, Method.Post);
                restRequest.AddHeader(HttpRequestHeader.Authorization.ToString(), "Bearer " + accesstoken);
                restRequest.AddParameter("application/json", ParameterType.RequestBody);
                var response = restClient.Execute(restRequest);
                return response;
            }
        }

        public static RestResponse PostAPI(string serviceURI, string accesstoken, string urlSuffix1, string customerRegistrationId, string urlSuffix2, object data)
        {
            string urlSuffix = urlSuffix1 + customerRegistrationId + urlSuffix2;
            using (WebClient wc = new WebClient())
            {
                var restClient = new RestClient(serviceURI);
                var restRequest = new RestRequest(urlSuffix, Method.Post);
                restRequest.AddHeader(HttpRequestHeader.Authorization.ToString(), "Bearer " + accesstoken);
                restRequest.AddParameter("application/json", data, ParameterType.RequestBody);
                var response = restClient.Execute(restRequest);
                return response;
            }
        }

        public static RestResponse PutAPI(string serviceURI, string accesstoken, string urlSuffix1, string customerRegistrationId, string urlSuffix2, object data)
        {
            string urlSuffix = urlSuffix1 + customerRegistrationId + urlSuffix2;
            using (WebClient wc = new WebClient())
            {
                var restClient = new RestClient(serviceURI);
                var restRequest = new RestRequest(urlSuffix, Method.Put);
                restRequest.AddHeader(HttpRequestHeader.Authorization.ToString(), "Bearer " + accesstoken);
                restRequest.AddParameter("application/json", data, ParameterType.RequestBody);
                var response = restClient.Execute(restRequest);
                return response;
            }
        }

        public class ApiException : Exception
        {
            public ApiException(HttpStatusCode statusCode, string content)
                : base($"API request failed with status code {statusCode}: {content}")
            {
                StatusCode = statusCode;
                Content = content;
            }

            public HttpStatusCode StatusCode { get; }
            public string Content { get; }
        }
        #endregion

        #region GET
        public static T Get<T>(this RestClient client, string resource) where T : new()
        {
            var request = new RestRequest(resource, Method.Get);
            return client.Execute<T>(request).Data;
        }

        public static T Get<T>(this RestClient client, RestRequest request) where T : new()
        {
            request.Method = Method.Get;
            return client.Execute<T>(request).Data;
        }

        public static RestResponse GetAPI(string serviceURI, string accesstoken)
        {
            using (WebClient wc = new WebClient())
            {
                var restClient = new RestClient(serviceURI);
                var restRequest = new RestRequest();
                restRequest.Method = Method.Get;
                restRequest.AddHeader(HttpRequestHeader.Authorization.ToString(), "Bearer " + accesstoken);
                //restRequest.AddParameter("application/json", ParameterType.RequestBody);
                var response = restClient.Execute(restRequest);
                return response;
            }
        }

        public static RestResponse GetAPI(string serviceURI, string accesstoken, string urlSuffix)
        {
            using (WebClient wc = new WebClient())
            {
                var restClient = new RestClient(serviceURI);
                var restRequest = new RestRequest(urlSuffix, Method.Get);
                restRequest.AddHeader(HttpRequestHeader.Authorization.ToString(), "Bearer " + accesstoken);
                //restRequest.AddParameter("application/json", ParameterType.RequestBody);
                var response = restClient.Execute(restRequest);
                return response;
            }
        }

        public static RestResponse GetAPI(string serviceURI, string urlSuffix, string username, string password)
        {
            string _DecryptedPassword = SecurePassword.Decrypt(password);
            System.Net.ServicePointManager.ServerCertificateValidationCallback +=
            delegate (object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate,
                       System.Security.Cryptography.X509Certificates.X509Chain chain,
                       System.Net.Security.SslPolicyErrors sslPolicyErrors)
            {
                return true; // **** Always accept
            };
            using (WebClient wc = new WebClient())
            {
                var restClient = new RestClient(serviceURI);
                var restRequest = new RestRequest(urlSuffix, Method.Get);
                restRequest.AddHeader("Content-Type", "application/json");
                restRequest.AddHeader("X-OpenIDM-Username", username);
                restRequest.AddHeader("X-OpenIDM-Password", _DecryptedPassword);
                var response = restClient.Execute(restRequest);
                return response;
            }

        }

        #endregion

        #region Get Access Token
        public static string GetAccessToken(string authURI, string username, string pwd, string resource, string consumerId, string clientId)
        {

            string _DecryptedPassword = SecurePassword.Decrypt(pwd);
            string URI = authURI;
            var reqparm = new NameValueCollection();
            reqparm.Add("username", username);
            reqparm.Add("password", _DecryptedPassword);
            reqparm.Add("consumerid", consumerId);
            reqparm.Add("resource", resource);
            reqparm.Add("client_id", clientId);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            using (WebClient wc = new WebClient())
            {
                wc.Headers[HttpRequestHeader.ContentType] = "application/x-www-form-urlencoded";
                byte[] responsebytes = wc.UploadValues(URI, "POST", reqparm);
                var responsebody = Encoding.UTF8.GetString(responsebytes);
                var responseObject = JObject.Parse(responsebody);
                var accesstoken = responseObject["accessToken"].ToString();
                return accesstoken;
            }
        }


        public static string GetForgeRockAccessToken(string authURI, string grantType, string username, string pwd, string clientId)
        {
            string _DecryptedPassword = SecurePassword.Decrypt(pwd);
            string URI = authURI;
            var reqparm = new NameValueCollection();
            reqparm.Add("grant_type", grantType);
            reqparm.Add("username", username);
            reqparm.Add("password", _DecryptedPassword);
            reqparm.Add("client_id", clientId);

            using (WebClient wc = new WebClient())
            {
                wc.Headers[HttpRequestHeader.ContentType] = "application/x-www-form-urlencoded";
                byte[] responsebytes = wc.UploadValues(URI, "POST", reqparm);
                var responsebody = Encoding.UTF8.GetString(responsebytes);
                var responseObject = JObject.Parse(responsebody);
                var accesstoken = responseObject["access_token"].ToString();
                return accesstoken;
            }
        }


        public static string GetForgeRockAccessToken(string content)
        {
            return JObject.Parse(content)["access_token"].ToString();
        }

        public static string GetAccessToken(string authURI, string grantType, string clientId, string clientSecretId)
        {
            string URI = authURI;
            var reqparm = new NameValueCollection();
            reqparm.Add("grant_type", grantType);
            reqparm.Add("client_id", clientId);
            reqparm.Add("client_secret", clientSecretId);

            using (WebClient wc = new WebClient())
            {
                wc.Headers[HttpRequestHeader.ContentType] = "application/x-www-form-urlencoded";
                wc.Headers[HttpRequestHeader.AcceptCharset] = "UTF-8";
                byte[] responsebytes = wc.UploadValues(URI, "POST", reqparm);
                var responsebody = Encoding.UTF8.GetString(responsebytes);
                var responseObject = JObject.Parse(responsebody);
                var accesstoken = responseObject["access_token"].ToString();
                return accesstoken;
            }
        }

        public static string GetAccessToken(string authURI, string clientId, string clientSecretId)
        {
            string URI = authURI;
            var reqparm = new NameValueCollection();
            reqparm.Add("client_id", clientId);
            reqparm.Add("client_secret", clientSecretId);

            using (WebClient wc = new WebClient())
            {
                wc.Headers[HttpRequestHeader.ContentType] = "application/x-www-form-urlencoded";
                wc.Headers[HttpRequestHeader.AcceptCharset] = "UTF-8";
                byte[] responsebytes = wc.UploadValues(URI, "POST", reqparm);
                var responsebody = Encoding.UTF8.GetString(responsebytes);
                var responseObject = JObject.Parse(responsebody);
                var accesstoken = responseObject["access_token"].ToString();
                return accesstoken;
            }
        }
        #endregion
    }
}

