﻿using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OneAutomationFramework.Drivers.Appium
{
    public static class AppiumElementExtensions
    {
        /// <summary>
        /// Click on the element
        /// </summary>
        /// <param name="element"></param>

        
        public static void ClickElement(this AppiumElement element)
        {
            element.Click();
        }


        /// <summary>
        /// Set text to the element
        /// </summary>
        /// <param name="element"></param>
        /// <param name="text"></param>

       
        public static void SetText(this AppiumElement element, string text)
        {
            element.Clear();
            element.SendKeys(text);
        }


        /// <summary>
        ///  Get the text from the element
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static string GetText(this AppiumElement element)
        {
            return element.Text;
        }

        /// <summary>
        /// Check if the element is displayed
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
      
        public static bool IsDisplayed(this AppiumElement element)
        {
            try
            {
                return element.Displayed;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        /// <summary>
        /// Check if the element is enabled
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        // Check if the element is enabled
        public static bool IsEnabled(this AppiumElement element)
        {
            return element.Enabled;
        }


        /// <summary>
        ///  Wait for the element to be visible
        /// </summary>
        /// <param name="element"></param>
        /// <param name="timeoutInSeconds"></param>
        public static void WaitForElementToBeVisible(this AppiumElement element, int timeoutInSeconds = 10)
        {
            WebDriverWait wait = new WebDriverWait(element.WrappedDriver, TimeSpan.FromSeconds(timeoutInSeconds));
            wait.Until(driver => element.Displayed);
        }

        /// <summary>
        /// Wait for the element to be clickable
        /// </summary>
        /// <param name="element"></param>
        /// <param name="timeoutInSeconds"></param>
        public static void WaitForElementToBeClickable(this AppiumElement element, int timeoutInSeconds = 10)
        {
            WebDriverWait wait = new WebDriverWait(element.WrappedDriver, TimeSpan.FromSeconds(timeoutInSeconds));
            wait.Until(driver => element.Enabled);
        }

        /// <summary>
        /// Scroll to the element
        /// </summary>
        /// <param name="element"></param>
        public static void ScrollToElement(this AppiumElement element)
        {
            ((IJavaScriptExecutor)element.WrappedDriver).ExecuteScript("arguments[0].scrollIntoView(true);", element);
        }

        /// <summary>
        /// Get the value of the specified attribute of the element
        /// </summary>
        /// <param name="element"></param>
        /// <param name="attributeName"></param>
        /// <returns></returns>
        public static string GetAttribute(this AppiumElement element, string attributeName)
        {
            return element.GetAttribute(attributeName);
        }

        /// <summary>
        /// Get the CSS value of a specified property of the element
        /// </summary>
        /// <param name="element"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public static string GetCssValue(this AppiumElement element, string propertyName)
        {
            return element.GetCssValue(propertyName);
        }

        /// <summary>
        /// Click on the element using JavaScript executor
        /// </summary>
        /// <param name="element"></param>
        public static void ClickWithJs(this AppiumElement element)
        {
            ((IJavaScriptExecutor)element.WrappedDriver).ExecuteScript("arguments[0].click();", element);
        }

        /// <summary>
        /// Execute JavaScript code on the element
        /// </summary>
        /// <param name="element"></param>
        /// <param name="script"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public static object ExecuteJavaScript(this AppiumElement element, string script, params object[] args)
        {
            return ((IJavaScriptExecutor)element.WrappedDriver).ExecuteScript(script, args);
        }

        /// <summary>
        ///  Get the tag name of the element
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static string GetTagName(this AppiumElement element)
        {
            return element.TagName;
        }

        /// <summary>
        ///  Check if the element is selected
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static bool IsSelected(this AppiumElement element)
        {
            return element.Selected;
        }

        /// <summary>
        ///  Select the element
        /// </summary>
        /// <param name="element"></param>
        public static void Select(this AppiumElement element)
        {
            if (!element.Selected)
            {
                element.Click();
            }
        }

        /// <summary>
        ///  Deselect the element
        /// </summary>
        /// <param name="element"></param>
        public static void Deselect(this AppiumElement element)
        {
            if (element.Selected)
            {
                element.Click();
            }
        }

        /// <summary>
        ///  Drag and drop the element to the specified target element
        /// </summary>
        /// <param name="element"></param>
        /// <param name="targetElement"></param>
        public static void DragAndDropTo(this AppiumElement element, AppiumElement targetElement)
        {
            new Actions(element.WrappedDriver)
                .DragAndDrop(element, targetElement)
                .Perform();
        }

        /// <summary>
        ///  Hover over the element
        /// </summary>
        /// <param name="element"></param>
        public static void HoverOver(this AppiumElement element)
        {
            new Actions(element.WrappedDriver)
                .MoveToElement(element)
                .Perform();
        }

        /// <summary>
        ///  Double click on the element
        /// </summary>
        /// <param name="element"></param>
        public static void DoubleClick(this AppiumElement element)
        {
            new Actions(element.WrappedDriver)
                .DoubleClick(element)
                .Perform();
        }

        /// <summary>
        ///  Right click on the element
        /// </summary>
        /// <param name="element"></param>
        public static void RightClick(this AppiumElement element)
        {
            new Actions(element.WrappedDriver)
                .ContextClick(element)
                .Perform();
        }
        /// <summary>
        /// Select value from dropdown
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <param name="value"></param>
        public static void SelectValueFromDropdown(this AppiumElement dropdownElement, string value)
        {
            SelectElement select = new SelectElement(dropdownElement);
            select.SelectByValue(value);
        }
        /// <summary>
        /// Select text from dropdown
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <param name="value"></param>
        public static void SelectTextFromDropdown(this AppiumElement dropdownElement, string value)
        {
            SelectElement select = new SelectElement(dropdownElement);
            select.SelectByText(value);
        }
        /// <summary>
        /// Select Index from Dropdown
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <param name="index"></param>
        public static void SelectIndexFromDropdown(this AppiumElement dropdownElement, int index)
        {
            SelectElement select = new SelectElement(dropdownElement);
            select.SelectByIndex(index);
        }
        /// <summary>
        /// Return Select text from dropdown
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <returns></returns>
        public static string GetSelectedOption(this AppiumElement dropdownElement)
        {
            SelectElement select = new SelectElement(dropdownElement);
            return select.SelectedOption.Text;
        }
        /// <summary>
        /// Return all the selected text from dropdown
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <returns></returns>
        public static List<string> GetAllSelectedOption(this AppiumElement dropdownElement)
        {
            SelectElement select = new SelectElement(dropdownElement);
            return select.AllSelectedOptions.Select(x => x.Text).ToList();
        }
        /// <summary>
        /// Deselect Text from dropdown
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <param name="text"></param>
        public static void DeselectTextFromDropdown(this AppiumElement dropdownElement,string text)
        {
            SelectElement select = new SelectElement(dropdownElement);
            select.DeselectByText(text);
        }
        /// <summary>
        /// Deselect Index from Dropdown
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <param name="index"></param>
        public static void DeselectIndexFromDropdown(this AppiumElement dropdownElement, int index)
        {
            SelectElement select = new SelectElement(dropdownElement);
            select.DeselectByIndex(index);
        }
        /// <summary>
        /// Deselect value from dropdown
        /// </summary>
        /// <param name="dropdownElement"></param>
        /// <param name="value"></param>
        public static void DeselectValueFromDropdown(this AppiumElement dropdownElement, string value)
        {
            SelectElement select = new SelectElement(dropdownElement);
            select.DeselectByValue(value);
        }
        /// <summary>
        /// Deselect all the Text from Dropdown
        /// </summary>
        /// <param name="dropdownElement"></param>
        public static void DeselectAllFromDropdown(this AppiumElement dropdownElement)
        {
            SelectElement select = new SelectElement(dropdownElement);
            select.DeselectAll();
        }


    }
}
