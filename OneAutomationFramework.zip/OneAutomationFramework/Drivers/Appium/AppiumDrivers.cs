﻿using Newtonsoft.Json;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.iOS;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Safari;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;


namespace OneAutomationFramework.Drivers.Appium
{
    /// <summary>
    /// Manages an app instance using Appium
    /// </summary>
    public class AppiumDrivers : IDisposable
    {
        private readonly IAppiumConfiguration _appiumConfiguration;
        private readonly IAppiumDriverInitialiser _driverInitialiser;
        protected readonly AsyncLazy<AppiumDriver> _currentBrowserLazy;
        ScenarioContext _scenarioContext;
        protected bool _isDisposed;

        public AppiumDrivers(IAppiumConfiguration appiumConfiguration, IAppiumDriverInitialiser driverInitialiser, ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
            _appiumConfiguration = appiumConfiguration;
            _driverInitialiser = driverInitialiser;
            _currentBrowserLazy = appiumConfiguration.platform switch
            {
                OS.android => new AsyncLazy<AppiumDriver>(CreateAndroidDriver),
                OS.ios => new AsyncLazy<AppiumDriver>(CreateIOSDriver),
                OS.Browserstack => appiumConfiguration.os.ToLower() switch
                {
                    "android" => new AsyncLazy<AppiumDriver>(CreateAndroidDriver),
                    "ios" => new AsyncLazy<AppiumDriver>(CreateIOSDriver),
                }
            };
        }

        /// <summary>
        /// The current Appium instance
        /// </summary>
        public AppiumDriver Current => _currentBrowserLazy.Value.Result;

        /// <summary>
        /// Creates a new instance of Appium 
        /// </summary>
        /// <returns></returns>
        private AppiumDriver CreateAndroidDriver()
        {
            var browserstackOptions = new AppiumOptions();
            if (_appiumConfiguration.runOnBrowserstack.Value)
            {
                Dictionary<string, object> bsOptions = new Dictionary<string, object>();
                bsOptions.Add("appiumVersion", "2.0.0");
                bsOptions.Add("userName", _appiumConfiguration.userKey);
                bsOptions.Add("accessKey", _appiumConfiguration.accessToken);
                browserstackOptions = GetBrowserstackCapabilities(_appiumConfiguration.device, _appiumConfiguration.os, _appiumConfiguration.bsBrowser, _appiumConfiguration.osVersion);
                browserstackOptions.AddAdditionalAppiumOption("browserstack.local", _appiumConfiguration.local);
                browserstackOptions.AddAdditionalAppiumOption("browserstack.user", _appiumConfiguration.userKey);
                browserstackOptions.AddAdditionalAppiumOption("browserstack.key", _appiumConfiguration.accessToken);
                browserstackOptions.AddAdditionalAppiumOption("name", _scenarioContext.ScenarioInfo.Title);
                var appid = GetAppId(_appiumConfiguration.appPath);
                browserstackOptions.AddAdditionalAppiumOption("Application", appid);
                //browserstackOptions.AddAdditionalCapability("app_url", appid);
                if (Environment.GetEnvironmentVariable("BROWSERSTACK_BUILD_NAME") != null)
                    browserstackOptions.AddAdditionalAppiumOption("buildName", Environment.GetEnvironmentVariable("BROWSERSTACK_BUILD_NAME"));
                else
                    browserstackOptions.AddAdditionalAppiumOption("buildName", _appiumConfiguration.projectName + DateTime.Now);
                browserstackOptions.AddAdditionalAppiumOption("project", _appiumConfiguration.projectName);
                browserstackOptions.AddAdditionalAppiumOption("bstack:options", bsOptions);
            }
            return _appiumConfiguration.platform switch
            {
                OS.android => _driverInitialiser.GetAndroidDriver(_appiumConfiguration),
                OS.Browserstack => _driverInitialiser.GetBrowserstackAndriodDriver(browserstackOptions),
                _ => throw new NotImplementedException($"Support for browser {_appiumConfiguration.platform} is not implemented yet"),
            };
        }
        /// <summary>
        /// Create a new instance of IOS Driver 
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        private AppiumDriver CreateIOSDriver()
        {
            var browserstackOptions = new AppiumOptions();
            if (_appiumConfiguration.runOnBrowserstack.Value)
            {
                Dictionary<string, object> bsOptions = new Dictionary<string, object>();
                bsOptions.Add("appiumVersion", "2.0.0");
                bsOptions.Add("userName", _appiumConfiguration.userKey);
                bsOptions.Add("accessKey", _appiumConfiguration.accessToken);
                bsOptions.Add("platformName", "ANY");
                browserstackOptions = GetBrowserstackCapabilities(_appiumConfiguration.device, _appiumConfiguration.os, _appiumConfiguration.bsBrowser, _appiumConfiguration.osVersion);
                //browserstackOptions.AddAdditionalAppiumOption("browserstack.local", _appiumConfiguration.local);
                //browserstackOptions.AddAdditionalAppiumOption("name", _scenarioContext.ScenarioInfo.Title);
                var appid = GetAppId(_appiumConfiguration.appPath);
                browserstackOptions.AddAdditionalAppiumOption("Application", appid);
                if (Environment.GetEnvironmentVariable("BROWSERSTACK_BUILD_NAME") != null)
                    browserstackOptions.AddAdditionalAppiumOption("buildName", Environment.GetEnvironmentVariable("BROWSERSTACK_BUILD_NAME"));
                else
                    browserstackOptions.AddAdditionalAppiumOption("buildName", _appiumConfiguration.projectName + DateTime.Now);
                browserstackOptions.AddAdditionalAppiumOption("project", _appiumConfiguration.projectName);
                browserstackOptions.AddAdditionalAppiumOption("bstack:options", bsOptions);
            }
            return _appiumConfiguration.platform switch
            {
                OS.ios => _driverInitialiser.GetIOSDriver(_appiumConfiguration),
                OS.Browserstack => _driverInitialiser.GetBrowserstackIOSDriver(browserstackOptions),
                _ => throw new NotImplementedException($"Support for browser {_appiumConfiguration.platform} is not implemented yet"),
            };
        }
        /// <summary>
        /// Disposes the Appium instance 
        /// </summary>
        public void Dispose()
        {
            if (_isDisposed)
            {
                return;
            }

            Task.Run(async delegate
            {
                Current.Close();
                Current.Dispose();
            });
            _isDisposed = true;
        }
        /// <summary>
        /// Get the Device Caps from browserstack
        /// </summary>
        /// <returns>Device cap from browser stack</returns>
        /// 
      
        public static List<BrowserstackResponse> GetDevicesList()
        {
            using (var httpClient = new HttpClient())
            {
                using (var request = new HttpRequestMessage(new HttpMethod("GET"), "https://api.browserstack.com/automate/browsers.json"))
                {
                    var base64authorization = Convert.ToBase64String(Encoding.ASCII.GetBytes("sivasikkan_RCYJK8:QaRYmqKNfUv46jcjgXv6"));
                    request.Headers.TryAddWithoutValidation("Authorization", $"Basic {base64authorization}");

                    var response = httpClient.SendAsync(request).Result;
                    return JsonConvert.DeserializeObject<List<BrowserstackResponse>>(response.Content.ReadAsStringAsync().Result);
                }
            }
        }

        public string GetAppId(string path)
        {
            HttpClient client = new HttpClient();
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "https://api-cloud.browserstack.com/app-automate/upload");
            request.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes("tobiaszzaleski_U7btvK:p6NdTZyCjh5pVTvxivwq")));
            MultipartFormDataContent content = new MultipartFormDataContent();
            content.Add(new ByteArrayContent(File.ReadAllBytes(path)), "file", Path.GetFileName(path));
            request.Content = content;

            HttpResponseMessage response = client.SendAsync(request).Result;
            response.EnsureSuccessStatusCode();
            string responseBody = response.Content.ReadAsStringAsync().Result;
            var json = JsonConvert.DeserializeObject<AppUpload>(responseBody);
            return json.app_url;
        }
        /// <summary>
        /// Filter out Device caps based on type of OS 
        /// </summary>
        /// <param name="device"></param>
        /// <param name="os"></param>
        /// <param name="browser"></param>
        /// <param name="osVersion"></param>
        /// <returns></returns>
        public AppiumOptions GetBrowserstackCapabilities(string device, string os, string browser, string osVersion)
        {
            var browserstackOptions = new AppiumOptions();
            var deviceList = GetDevicesList();
            var deviceCap = deviceList.Where(x => x.device == device && x.os_version == osVersion).FirstOrDefault();
            if (deviceCap == null)
                deviceCap = deviceList.Where(x => x.device == device).FirstOrDefault();
            browserstackOptions.PlatformName = "ANY";
            //browserstackOptions.PlatformName = deviceCap.os;
            browserstackOptions.PlatformVersion = deviceCap.os_version;
            browserstackOptions.DeviceName = deviceCap.device;
            if (os.ToLower() == "android")
                browserstackOptions.AutomationName = "UiAutomator2";
            else
                browserstackOptions.AutomationName = "XCUITest";
            browserstackOptions.AddAdditionalAppiumOption("automationVersion", "latest");
            return browserstackOptions;
        }

        /// <summary>
        /// It return the browser type
        /// </summary>
        /// <param name="browser"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public static dynamic GetBrowserOptions(string browser)
        {
            return browser.ToLower() switch
            {
                "chrome" => new ChromeOptions(),
                "firefox" => new FirefoxOptions(),
                "edge" => new EdgeOptions(),
                "safari" => new SafariOptions(),
                _ => throw new NotImplementedException($"Support for browser {browser} is not implemented yet"),
            };
        }
    }
}
