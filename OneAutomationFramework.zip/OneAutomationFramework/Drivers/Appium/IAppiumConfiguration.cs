﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace OneAutomationFramework.Drivers
{
    public interface IAppiumConfiguration
    {
        OS platform { get; }

        string[]? Arguments { get; }

        float? DefaultTimeout { get; }

        bool? Headless { get; }

        string? appPath { get; }

        string? TraceDir { get; }

        bool? runOnBrowserstack { get; }

        string? userKey { get; }

        string? accessToken { get; }

        bool? privateMode { get; }

        bool? local { get; }

        string? build { get; }

        string? device { get; }

        string? os { get; }
        string? osVersion { get; }
        string? bsBrowser { get; }
        string? bsbrowserVersion { get; }

        string? projectName { get; }


    }

    public class AppiumConfiguration : IAppiumConfiguration
    {
        private class SpecFlowActionJson
        {
            [JsonInclude]
            public AppiumSpecFlowJsonPart Appium { get; private set; } = new AppiumSpecFlowJsonPart();
        }

        private class AppiumSpecFlowJsonPart
        {
            [JsonInclude]
            public OS platform { get; private set; }

            [JsonInclude]
            public string[]? Arguments { get; private set; }

            [JsonInclude]
            public float? DefaultTimeout { get; private set; }

            [JsonInclude]
            public bool? Headless { get; private set; }

            [JsonInclude]
            public string? appPath { get; private set; }

            [JsonInclude]
            public string? TraceDir { get; private set; }

            [JsonInclude]
            public bool? runOnBrowserstack { get; private set; }

            [JsonInclude]
            public string? userKey { get; private set; }

            [JsonInclude]
            public string? accessToken { get; private set; }

            [JsonInclude]
            public bool? local { get; private set; }

            [JsonInclude]
            public string? build { get; private set; }

            [JsonInclude]
            public string? device { get; private set; }

            [JsonInclude]
            public string? os { get; private set; }

            [JsonInclude]
            public string? osVersion { get; private set; }

            [JsonInclude]
            public string? bsBrowser { get; private set; }

            [JsonInclude]
            public string? browserVersion { get; private set; }

            [JsonInclude]
            public bool? privateMode { get; private set; }

            [JsonInclude]
            public string? projectName { get; private set; }
        }

        private readonly Lazy<SpecFlowActionJson> _specflowJsonPart;

        private SpecFlowActionJson LoadSpecFlowJson()
        {
            var json = Load();

            if (string.IsNullOrWhiteSpace(json))
            {
                return new SpecFlowActionJson();
            }

            var jsonSerializerOptions = new JsonSerializerOptions()
            {
                PropertyNameCaseInsensitive = true
            };

            jsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());

            var specflowActionConfig = System.Text.Json.JsonSerializer.Deserialize<SpecFlowActionJson>(json, jsonSerializerOptions);

            return specflowActionConfig ?? new SpecFlowActionJson();
        }

        /// <summary>
        /// Provides the configuration details for the Appium instance
        /// </summary>
        /// <param name="specFlowActionJsonLoader"></param>
        public AppiumConfiguration()
        {
            _specflowJsonPart = new Lazy<SpecFlowActionJson>(LoadSpecFlowJson);
        }

        /// <summary>
        /// The browser specified in the configuration
        /// </summary>
        public OS platform => _specflowJsonPart.Value.Appium.platform;

        /// <summary>
        /// Additional arguments used when launching the browser
        /// </summary>
        public string[]? Arguments => _specflowJsonPart.Value.Appium.Arguments;

        /// <summary>
        /// The default timeout used to configure the browser
        /// </summary>
        public float? DefaultTimeout => _specflowJsonPart.Value.Appium.DefaultTimeout;

        /// <summary>
        /// Whether the browser should launch headless
        /// </summary>
        public bool? Headless => _specflowJsonPart.Value.Appium.Headless;

        /// <summary>
        /// How many miliseconds elapse between every action 
        /// </summary>
        public string? appPath => _specflowJsonPart.Value.Appium.appPath;

        /// <summary>
        /// If specified, traces are saved into this directory 
        /// </summary>
        public string? TraceDir => _specflowJsonPart.Value.Appium.TraceDir;

        /// <summary>
        /// Whether the browser should runon browsertack
        /// </summary>
        public bool? runOnBrowserstack => _specflowJsonPart.Value.Appium.runOnBrowserstack;
        /// <summary>
        /// Whether the browser should runon browsertack
        /// </summary>

        public string? userKey => _specflowJsonPart.Value.Appium.userKey;
        /// <summary>
        /// Whether the browser should runon browsertack
        /// </summary>
        public string? accessToken => _specflowJsonPart.Value.Appium.accessToken;
        /// <summary>
        /// Whether the browser should runon browsertack
        /// </summary>
        public bool? local => _specflowJsonPart.Value.Appium.local;

        /// <summary>
        /// Whether the browser should runon browsertack
        /// </summary>
        public string? build => _specflowJsonPart.Value.Appium.build;

        public string? device => _specflowJsonPart.Value.Appium.device;

        public string? os => _specflowJsonPart.Value.Appium.os;

        public string? osVersion => _specflowJsonPart.Value.Appium.osVersion;

        public string? bsBrowser => _specflowJsonPart.Value.Appium.bsBrowser;

        public string? bsbrowserVersion => _specflowJsonPart.Value.Appium.browserVersion;

        public bool? privateMode => _specflowJsonPart.Value.Appium.privateMode;

        public string? projectName => _specflowJsonPart.Value.Appium.projectName;

        private string? GetFilePathToConfigurationFile(string configurationFileName)
        {
            if (AppDomain.CurrentDomain.BaseDirectory is not null)
            {
                var specflowJsonFileInAppDomainBaseDirectory =
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, configurationFileName);

                if (File.Exists(specflowJsonFileInAppDomainBaseDirectory))
                {
                    return specflowJsonFileInAppDomainBaseDirectory;
                }

                var specflowJsonFileTwoDirectoriesUp =
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", configurationFileName);

                if (File.Exists(specflowJsonFileTwoDirectoriesUp))
                {
                    return specflowJsonFileTwoDirectoriesUp;
                }
            }

            var specflowJsonFileInCurrentDirectory = Path.Combine(Environment.CurrentDirectory, configurationFileName);

            if (File.Exists(specflowJsonFileInCurrentDirectory))
            {
                return specflowJsonFileInCurrentDirectory;
            }

            return null;
        }

        public string Load()
        {
            var specFlowJsonFilePath = GetFilePathToConfigurationFile("AppiumConfig.json");

            if (specFlowJsonFilePath != null)
            {
                var content = File.ReadAllText(specFlowJsonFilePath);

                return content;
            }

            return "{}";
        }

        public dynamic LoadJson()
        {
            var specFlowJsonFilePath = GetFilePathToConfigurationFile("AppiumConfig.json");
            var content = File.ReadAllText(specFlowJsonFilePath);
            return JsonConvert.DeserializeObject(content);

        }
    }

}