﻿using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.MultiTouch;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.iOS;
using OpenQA.Selenium.Interactions;
using System.Diagnostics;
using SeleniumExtras.WaitHelpers;

namespace OneAutomationFramework.Drivers.Appium
{
    public static class AppiumDriverExtensions
    {
        public enum GestureType
        {
            Tap,
            Swipe,
            LongPress,
            Pinch,
            Zoom
        }
        /// <summary>
        ///  Extension method to wait for an element to be visible
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="by"></param>
        /// <param name="timeoutInSeconds"></param>
        public static void WaitForElementToBeVisible(this AppiumDriver driver, MobileBy by, int timeoutInSeconds = 10)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
            wait.Until(ExpectedConditions.ElementIsVisible(by));
        }

        /// <summary>
        ///  Extension method to wait for an element to be clickable
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="by"></param>
        /// <param name="timeoutInSeconds"></param>
        public static void WaitForElementToBeClickable(this AppiumDriver driver, MobileBy by, int timeoutInSeconds = 10)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
            wait.Until(ExpectedConditions.ElementToBeClickable(by));
        }

        /// <summary>
        ///  Extension method to click on an element using JavaScript
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="element"></param>
        public static void ClickWithJavaScript(this AppiumDriver driver, AppiumElement element)
        {
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", element);
        }

        /// <summary>
        ///  Extension method to swipe left on the screen
        /// </summary>
        /// <param name="driver"></param>
        public static void SwipeLeft(this AppiumDriver driver)
        {
            // Swipe left on the screen
            var size = driver.Manage().Window.Size;
            var startX = (int)(size.Width * 0.9);
            var endX = (int)(size.Width * 0.1);
            var startY = size.Height / 2;

            var action = new TouchAction(driver);
            action.Press(startX, startY).Wait(500).MoveTo(endX, startY).Release().Perform();
        }

        /// <summary>
        ///  Extension method to swipe right on the screen
        /// </summary>
        /// <param name="driver"></param>
        public static void SwipeRight(this AppiumDriver driver)
        {
            // Swipe right on the screen
            var size = driver.Manage().Window.Size;
            var startX = (int)(size.Width * 0.1);
            var endX = (int)(size.Width * 0.9);
            var startY = size.Height / 2;

            var action = new TouchAction(driver);
            action.Press(startX, startY).Wait(500).MoveTo(endX, startY).Release().Perform();
        }
        /// <summary>
        ///Extension Method to Find Elements using AccessbilityIds 
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="accessibilityId"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>

        public static IReadOnlyCollection<AppiumElement> FindElementsByAccessibilityIds(this AppiumDriver driver, string accessibilityId)
        {
            if (driver == null)
            {
                throw new ArgumentNullException(nameof(driver));
            }

            if (string.IsNullOrEmpty(accessibilityId))
            {
                throw new ArgumentNullException(nameof(accessibilityId));
            }

            return driver.FindElements(MobileBy.AccessibilityId(accessibilityId));
        }
        /// <summary>
        /// Extension Method to FindElements by Class Name
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="className"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static IReadOnlyCollection<AppiumElement> FindElementsByClassName(this AppiumDriver driver, string className)
        {
            if (driver == null)
            {
                throw new ArgumentNullException(nameof(driver));
            }
            if (string.IsNullOrEmpty(className))
            {
                throw new ArgumentNullException(nameof(className));
            }
            return driver.FindElements(MobileBy.ClassName(className));
        }
        /// <summary>
        /// Extension Method to Find Elements by Xpath
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="xpath"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static IReadOnlyCollection<AppiumElement> FindElementsByXPath(this AppiumDriver driver, string xpath)
        {
            if (driver == null)
            {
                throw new ArgumentNullException(nameof(driver));
            }
            if (string.IsNullOrEmpty(xpath))
            {
                throw new ArgumentNullException(nameof(xpath));
            }
            return driver.FindElements(MobileBy.XPath(xpath));
        }
        /// <summary>
        /// Method to Change the Screen Orientation
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="orientation"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public static void ChangeScreenOrientation(this AppiumDriver driver, ScreenOrientation orientation)
        {
            if (driver == null)
            {
                throw new ArgumentNullException(nameof(driver));
            }

            var appiumOrientation = ConvertToAppiumOrientation(orientation);
            driver.ExecuteScript("mobile: orientation", new { orientation = appiumOrientation });
        }
        private static string ConvertToAppiumOrientation(ScreenOrientation orientation)
        {
            return orientation switch
            {
                ScreenOrientation.Portrait => "PORTRAIT",
                ScreenOrientation.Landscape => "LANDSCAPE",
                _ => throw new ArgumentException("Invalid ScreenOrientation value", nameof(orientation))
            };
        }
        /// <summary>
        ///Method set the Clipboard value for Android OS 
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="value"></param>
        private static void SetClipboardValue(this AndroidDriver driver, string value)
        {
            driver.SetClipboardText(value, "plaintext");
        }
        /// <summary>
        /// Method set the Clipboard value for IOS OS 
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="value"></param>
        private static void SetClipboardValue(this IOSDriver driver, string value)
        {
            driver.SetClipboardText(value, "plaintext");
        }

        /// <summary>
        /// How to use: 
        /// var tapParams = new Dictionary<string, object> 
        /// {
        ///      { "x", 100 },
        ///      { "y", 200 }
        /// }
        /// driver.PerformGesture(GestureType.Tap, tapParams);
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="gestureType"></param>
        /// <param name="parameters"></param>
        public static void PerformGesture(this AppiumDriver driver, GestureType gestureType, Dictionary<string, object> parameters)
        {
            if (driver == null)
            {
                throw new ArgumentNullException(nameof(driver));
            }

            TouchAction touchAction = new TouchAction(driver);

            switch (gestureType)
            {
                case GestureType.Tap:
                    int x = Convert.ToInt32(parameters["x"]);
                    int y = Convert.ToInt32(parameters["y"]);
                    touchAction.Tap(x, y).Perform();
                    break;
                case GestureType.Swipe:
                    int startX = Convert.ToInt32(parameters["startX"]);
                    int startY = Convert.ToInt32(parameters["startY"]);
                    int endX = Convert.ToInt32(parameters["endX"]);
                    int endY = Convert.ToInt32(parameters["endY"]);
                    int duration = Convert.ToInt32(parameters["duration"]);
                    touchAction.Press(startX, startY).Wait(duration).MoveTo(endX, endY).Release().Perform();
                    break;
                case GestureType.LongPress:
                    int xLong = Convert.ToInt32(parameters["x"]);
                    int yLong = Convert.ToInt32(parameters["y"]);
                    touchAction.LongPress(xLong, yLong).Perform();
                    break;
                case GestureType.Pinch:
                    double scale = Convert.ToDouble(parameters["scale"]);
                    int centerX = Convert.ToInt32(parameters["centerX"]);
                    int centerY = Convert.ToInt32(parameters["centerY"]);
                    touchAction.Press(centerX, centerY).MoveTo(centerX, centerY - 100).Wait(1000)
                        .MoveTo(centerX, centerY + 100).Release().Perform();
                    break;
                case GestureType.Zoom:
                    double zoomScale = Convert.ToDouble(parameters["scale"]);
                    int zoomCenterX = Convert.ToInt32(parameters["centerX"]);
                    int zoomCenterY = Convert.ToInt32(parameters["centerY"]);
                    touchAction.Press(zoomCenterX, zoomCenterY - 100).MoveTo(zoomCenterX, zoomCenterY).Wait(1000)
                        .MoveTo(zoomCenterX, zoomCenterY + 100).Release().Perform();
                    break;
                default:
                    throw new ArgumentException("Invalid GestureType value", nameof(gestureType));
            }
        }
        /// <summary>
        /// Method to Toggle Airplone mode
        /// </summary>
        /// <param name="driver"></param>
        public static void ToggleAirplaneMode(this AppiumDriver driver)
        {
            driver.ExecuteScript("mobile: toggleAirplaneMode");
        }
       /// <summary>
       /// Method to toggle Mobiledata 
       /// </summary>
       /// <param name="driver"></param>
        public static void ToggleData(this AppiumDriver driver)
        {
            driver.ExecuteScript("mobile: toggleData");
        }
        /// <summary>
        /// Method to toggle Location Service
        /// </summary>
        /// <param name="driver"></param>
        public static void ToggleLocationServices(this AppiumDriver driver)
        {
            driver.ExecuteScript("mobile: shell", new Dictionary<string, object>
            {
                ["command"] = "settings put secure location_providers_allowed -gps",
                ["args"] = new List<string> { "network" }
            });
        }
        /// <summary>
        /// Method to ToggleWifi
        /// </summary>
        /// <param name="driver"></param>
        public static void ToggleWifi(this AppiumDriver driver)
        {
            driver.ExecuteScript("mobile: toggleWiFi");
        }

        /// <summary>
        ///  Method to perform press key action
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="key"></param>
        public static void PressKey(this AppiumDriver driver, string key)
        {
            Actions action = new Actions(driver);
            action.SendKeys(key).Perform();
        }

        /// <summary>
        ///  Method to perform long press key action
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="key"></param>
        public static void LongPressKey(this AppiumDriver driver, string key)
        {
            Actions action = new Actions(driver);
            action.KeyDown(key).KeyUp(key).Perform();
        }

        /// <summary>
        ///  Method to perform release key action
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="key"></param>
        public static void ReleaseKey(this AppiumDriver driver, string key)
        {
            Actions action = new Actions(driver);
            action.KeyUp(key).Perform();
        }

        /// <summary>
        ///  Method to perform typing action
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="text"></param>
        public static void TypeText(this AppiumDriver driver, string text)
        {
            Actions action = new Actions(driver);
            action.SendKeys(text).Perform();
        }
        /// <summary>
        /// Method to perform clear text action
        /// </summary>
        /// <param name="driver"></param>
       
        public static void ClearText(this AppiumDriver driver)
        {
            Actions action = new Actions(driver);
            action.SendKeys(Keys.Control + "a").SendKeys(Keys.Delete).Perform();
        }
        /// <summary>
        /// Method to Lock the Android device
        /// </summary>
        /// <param name="driver"></param>
        public static void LockDevice(this AndroidDriver driver)
        {
            driver.Lock();
        }
        /// <summary>
        /// Method to Unlock the Android device
        /// </summary>
        /// <param name="driver"></param>
        public static void UnlockDevice(this AndroidDriver driver)
        {
            driver.Unlock();
        }
        /// <summary>
        /// Method to Lock IOS device
        /// </summary>
        /// <param name="driver"></param>
        public static void LockDevice(this IOSDriver driver)
        {
            driver.Lock();
        }

        /// <summary>
        /// Method to Unlock the IOS device
        /// </summary>
        /// <param name="driver"></param>
        public static void UnlockDevice(this IOSDriver driver)
        {
            driver.Unlock();
        }
        /// <summary>
        /// Method to Unlocak the device
        /// </summary>
        /// <param name="driver"></param>
        public static void UnlockDevice(this AppiumDriver driver)
        {
            // Unlock the device by sending an empty passcode
            driver.ExecuteScript("mobile: performTouchID", new Dictionary<string, object>
            {
                ["match"] = true,
                ["data"] = new List<int>()
            });
        }


        /// <summary>
        /// Method to read notifications on Android
        /// </summary>
        /// <returns></returns>
        // 
        public static string[] ReadNotificationsAndroid()
        {
            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "adb",
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    Arguments = "shell dumpsys notification"
                }
            };
            process.Start();
            string output = process.StandardOutput.ReadToEnd();
            process.WaitForExit();
            string[] notifications = output.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            return notifications;
        }
        /// <summary>
        /// Extension Method to Open the Android Notification 
        /// </summary>
        /// <param name="driver"></param>
        public static void OpenNotifications(AndroidDriver driver)
        {
            driver.OpenNotifications();
        }
        /// <summary>
        /// Extension to Zoom
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="scale"></param>
        /// <param name="zoom"></param>
        public static void Zoom(AppiumDriver driver, double scale, string zoom)
        {
            // Get the center coordinates of the screen
            var windowSize = driver.Manage().Window.Size;
            var centerX = windowSize.Width / 2;
            var centerY = windowSize.Height / 2;

            // Calculate the zoom in/out coordinates based on the scale value
            var zoomInX = centerX - (centerX * scale);
            var zoomInY = centerY - (centerY * scale);
            var zoomOutX = centerX + (centerX * scale);
            var zoomOutY = centerY + (centerY * scale);

            // Create a MultiTouchAction instance
            var multiTouchAction = new MultiAction(driver);

            if (zoom.ToLower() == "in")
            {
                // Perform the zoom in action
                var zoomInAction = new TouchAction(driver)
                    .Press(zoomInX, zoomInY)
                    .Wait(500)
                    .MoveTo(zoomOutX, zoomOutY)
                    .Release();
                multiTouchAction.Add(zoomInAction);
            }
            else
            {
                // Perform the zoom out action
                var zoomOutAction = new TouchAction(driver)
                    .Press(zoomOutX, zoomOutY)
                    .Wait(500)
                    .MoveTo(zoomInX, zoomInY)
                    .Release();
                multiTouchAction.Add(zoomOutAction);
            }

            // Perform the MultiTouchAction
            multiTouchAction.Perform();
        }
        /// <summary>
        /// Extension Method to Scroll by type of direction 
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="direction"></param>
        /// <param name="duration"></param>
        /// <exception cref="ArgumentException"></exception>
        public static void Scroll(this AppiumDriver driver, ScrollDirection direction, int duration = 1000)
        {
            var windowSize = driver.Manage().Window.Size;
            int startX, startY, endX, endY;

            switch (direction)
            {
                case ScrollDirection.Up:
                    startX = windowSize.Width / 2;
                    startY = windowSize.Height * 3 / 4;
                    endX = startX;
                    endY = windowSize.Height / 4;
                    break;

                case ScrollDirection.Down:
                    startX = windowSize.Width / 2;
                    startY = windowSize.Height / 4;
                    endX = startX;
                    endY = windowSize.Height * 3 / 4;
                    break;

                case ScrollDirection.Left:
                    startX = windowSize.Width * 3 / 4;
                    startY = windowSize.Height / 2;
                    endX = windowSize.Width / 4;
                    endY = startY;
                    break;

                case ScrollDirection.Right:
                    startX = windowSize.Width / 4;
                    startY = windowSize.Height / 2;
                    endX = windowSize.Width * 3 / 4;
                    endY = startY;
                    break;

                default:
                    throw new ArgumentException("Invalid scroll direction provided.");
            }

            new TouchAction(driver)
                .Press(startX, startY)
                .Wait(duration)
                .MoveTo(endX, endY)
                .Release()
                .Perform();
        }
        public enum ScrollDirection
        {
            Up,
            Down,
            Left,
            Right
        }
        /// <summary>
        /// Extension Method to Capture Screenshot
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="filePath"></param>
        /// <param name="imageFormat"></param>
        public static void CaptureScreenshot(this AppiumDriver driver, string filePath, ScreenshotImageFormat imageFormat = ScreenshotImageFormat.Png)
        {
            ITakesScreenshot screenshotDriver = driver as ITakesScreenshot;
            Screenshot screenshot = screenshotDriver.GetScreenshot();
            screenshot.SaveAsFile(filePath, imageFormat);
        }
        /// <summary>
        /// Extension Method to Install App
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="path"></param>
        public static void InstallApp(this AppiumDriver driver, string path)
        {
            driver.InstallApp(path);
        }
        /// <summary>
        /// Extension Method to Uninstall App
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="appName"></param>
        public static void UninstallApp(this AppiumDriver driver, string appName)
        {
            driver.UninstallApp(appName);
        }
        /// <summary>
        /// Extension Method to Install App on Android
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="path"></param>
        public static void InstallApp(this AndroidDriver driver, string path)
        {
            driver.InstallApp(path);
        }
        /// <summary>
        /// Extension Method to Uninstall App on Android
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="appName"></param>
        public static void UninstallApp(this AndroidDriver driver, string appName)
        {
            driver.UninstallApp(appName);
        }

        /// <summary>
        /// Extension Method to Install App on IOS
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="path"></param>
        public static void InstallApp(this IOSDriver driver, string path)
        {
            var args = new Dictionary<string, string>();
            args.Add("app", path);
            driver.ExecuteScript("mobile: installApp", args);
        }
        /// <summary>
        /// Extension Method to Uninstall the App on IOS 
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="appName"></param>
        public static void UninstallApp(this IOSDriver driver, string appName)
        {
            var args = new Dictionary<string, string>();
            args.Add("bundleId", appName);
            driver.ExecuteScript("mobile: removeApp", args);
        }
        /// <summary>
        /// Extension Method to Check App is installed or not
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="appName"></param>
        /// <returns></returns>
        public static bool IsAppInstalled(this AppiumDriver driver, string appName)
        {
            return driver.IsAppInstalled(appName);
        }
        /// <summary>
        /// Extension Method to Launch the App
        /// </summary>
        /// <param name="driver"></param>
        public static void LaunchApp(this AppiumDriver driver)
        {
            driver.LaunchApp();
        }
    }
}