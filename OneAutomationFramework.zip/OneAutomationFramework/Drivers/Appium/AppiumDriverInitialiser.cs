﻿using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Enums;
using OpenQA.Selenium.Appium.iOS;
using OpenQA.Selenium.Appium.Service;
using System;
using TechTalk.SpecFlow;


namespace OneAutomationFramework.Drivers.Appium
{
    public interface IAppiumDriverInitialiser
    {
        AppiumDriver GetAndroidDriver(IAppiumConfiguration config);
        AppiumDriver GetIOSDriver(IAppiumConfiguration config);
        AppiumDriver GetBrowserstackAndriodDriver(AppiumOptions options);
        AppiumDriver GetBrowserstackIOSDriver(AppiumOptions options);
    }

    public class AppiumDriverInitialiser : IAppiumDriverInitialiser
    {

        public const float DEFAULT_TIMEOUT = 30f;


        /// <summary>
        /// Setting Additional Capabilities of Android Driver 
        /// returning  a Android driver instance
        /// </summary>
        /// <param name="config"></param>
        /// <returns></returns>
        public AppiumDriver GetAndroidDriver(IAppiumConfiguration config)
        {
            AppiumOptions options = new AppiumOptions();

            options.AddAdditionalAppiumOption(MobileCapabilityType.PlatformName, config.os);
            options.AddAdditionalAppiumOption(MobileCapabilityType.DeviceName, config.device);
            options.AddAdditionalAppiumOption(MobileCapabilityType.App, config.appPath);
            return new AndroidDriver(StartAppiumLocalService(), options);

        }
        /// <summary>
        /// Setting Additional Capabilities of IOS Driver 
        /// returning  a IOS driver instance
        /// </summary>
        /// <param name="config"></param>
        /// <returns></returns>
        public AppiumDriver GetIOSDriver(IAppiumConfiguration config)
        {
            AppiumOptions options = new AppiumOptions();
            options.AddAdditionalAppiumOption(MobileCapabilityType.PlatformName, config.os);
            options.AddAdditionalAppiumOption(MobileCapabilityType.DeviceName, config.device);
            options.AddAdditionalAppiumOption(MobileCapabilityType.App, config.appPath);
            return new IOSDriver(StartAppiumLocalService(), options);
        }

        /// <summary>
        /// Browser Stack Android Instance
        /// </summary>
        /// <param name="options"></param>
        /// <returns></returns>
        public AppiumDriver GetBrowserstackAndriodDriver(AppiumOptions options)
        {
            return new AndroidDriver(new Uri("http://hub-cloud.browserstack.com/"), options);
        }
        /// <summary>
        /// Browser Stack IOS Instance
        /// </summary>
        /// <param name="options"></param>
        /// <returns></returns>
        public AppiumDriver GetBrowserstackIOSDriver(AppiumOptions options)
        {
            return new IOSDriver(new Uri("http://hub-cloud.browserstack.com/wd/hub"), options);
        }


        private static float? ToMilliseconds(float? seconds)
        {
            return seconds * 1000;
        }
        /// <summary>
        /// Create a new Instance of Appium local service with default port number
        /// </summary>
        /// <returns></returns>
        public AppiumLocalService StartAppiumLocalService()
        {
            var _appiumLocalService = new AppiumServiceBuilder().UsingAnyFreePort().Build();
            if (_appiumLocalService.IsRunning)
                _appiumLocalService.Start();

            return _appiumLocalService;
        }


        /// <summary>
        /// Create a new instance of Appium local service
        /// </summary>
        /// <param name="portNumber"></param>
        /// <returns></returns>
        public AppiumLocalService StartAppiumLocalService(int portNumber)
        {
            var _appiumLocalService = new AppiumServiceBuilder().UsingPort(portNumber).Build();
            if (_appiumLocalService.IsRunning)
                _appiumLocalService.Start();

            ScenarioContext.Current["_appiumLocalService"] = _appiumLocalService;
            return _appiumLocalService;

        }
    }
}
