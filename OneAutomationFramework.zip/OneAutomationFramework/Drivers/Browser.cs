﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OneAutomationFramework.Drivers
{
    public enum Browser
    {
        None = 0,
        Chromium = 1,
        Firefox = 2,
        Edge = 3,
        Chrome = 5,
        Webkit = 6,
        Browserstack = 7
    }

    public enum OS
    {
        None = 0,
        ios = 1,
        android = 2,
        Windows = 3,
        Browserstack = 4
    }

    public enum osVersion
    {
        None = 0,
        ios16 = 1,
        ios15 = 2,
        ios14 = 3,
        andorid11=4,
        andorid12=5,
        andorid13=6
    }
    public enum deviceType
    {
        None = 0,
        phone = 1,
        tabs = 2,
        desktop=3
    }

}
