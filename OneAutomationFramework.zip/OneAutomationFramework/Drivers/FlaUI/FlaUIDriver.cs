﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlaUI.Core;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.AutomationElements.Infrastructure;
using FlaUI.Core.Conditions;
using FlaUI.Core.Definitions;
using FlaUI.Core.Tools;
using FlaUI.UIA3;
using LoggerLibrary;
using TechTalk.SpecFlow;

namespace OneAutomationFramework.Drivers.FlaUI
{
    /// <summary>
    /// Manages a desktop application instance using FlaUI
    /// </summary>
    public class FlaUIDriver : IDisposable
    {
        private readonly IFlaUIConfiguration _flaUIConfiguration;
        protected readonly AsyncLazy<Application> _currentAppLazy;
        public ScenarioContext _scenarioContext;
        protected bool _isDisposed;
        public FlaUIDriver(IFlaUIConfiguration flaUIConfiguration, ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
            _flaUIConfiguration = flaUIConfiguration;
            if (_currentAppLazy == null)
                _currentAppLazy = new AsyncLazy<Application>(CreateFlaUIApp);
        }

        /// <summary>
        /// The current FlaUI Application instance
        /// </summary>
        public Application Current => _currentAppLazy.Value.Result;

        /// <summary>
        /// Creates a new instance of the desktop application
        /// </summary>
        /// <returns></returns>
        public Application CreateFlaUIApp()
        {
            try
            {
                var app = Application.Launch(_flaUIConfiguration.WinAppPath);
                app.WaitWhileBusy();
                Logger.Info("Lanch app si successfull");
                return app;
            }
            catch (Exception e)
            {
                Logger.Error("Launching application failed" + e.Message);
                throw;
            }
        }

        /// <summary>
        /// Gets the main window of the application
        /// </summary>
        /// <returns></returns>
        public Window GetMainWindow()
        {
            try
            {
                var app = Current;
                var mainWindow = app.GetMainWindow(new UIA3Automation());
                return mainWindow;
            }
            catch (Exception e)
            {
                Logger.Error("Failed to return main window" + e.Message);
                throw;
            }
        }


        /// <summary>
        /// Finds an element by the specified automation ID
        /// </summary>
        /// <param name="automationId"></param>
        /// <returns></returns>
        public AutomationElement FindElementByAutomationId(string automationId)
        {
            try
            {
                var mainWindow = GetMainWindow();
                var element = mainWindow.FindFirstDescendant(cf => cf.ByAutomationId(automationId));

                return element;
            }
            catch (Exception e)
            {
                Logger.Error("Unable to return automation element" + e.Message);
                throw;
            }
        }

        public void Dispose()
        {
            if (_isDisposed)
            {
                return;
            }
            //Current.Close();
            //Current.Dispose();
            _currentAppLazy?.Value?.Result.Kill();
            _isDisposed = true;
        }
    }
}

