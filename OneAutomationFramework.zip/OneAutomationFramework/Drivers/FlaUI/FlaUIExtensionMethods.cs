﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using FlaUI.Core;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Definitions;
using FlaUI.Core.Exceptions;
using FlaUI.Core.Input;
using FlaUI.Core.WindowsAPI;
using FlaUI.UIA3;
using FlaUI.UIA3.Patterns;

namespace OneAutomationFramework.Drivers.FlaUI
{
    public static class FlaUIExtensionMethods
    {
        /// <summary>
        /// Clicks on the element
        /// </summary>
        public static void ClickElement(this AutomationElement element)
        {
            element.Click();
        }

        /// <summary>
        /// Right Click on the element
        /// </summary>
        public static void xtRightClick(this AutomationElement element)
        {
            element.RightClick();
        }

        /// <summary>
        /// Types text to the textbox
        /// </summary>
        public static void TypeText(this TextBox textBox, string text)
        {
            textBox.Focus();
            textBox.Text = "";
            textBox.Text = text;
        }

        /// <summary>
        /// Selects the checkbox
        /// </summary>
        public static void SelectItem(this ComboBox comboBox, string item)
        {
            comboBox.Select(item);
        }

        /// <summary>
        /// The current FlaUI Application instance
        /// </summary>
        public static AutomationElement[] GetChildElement(this AutomationElement element)
        {
            return element.FindAllDescendants();
        }


        /// <summary>
        /// Selects an option from a dropdown element by text
        /// </summary>
        /// <param name="comboBox"></param>
        /// <param name="item"></param>
        public static void SelectDropdownItem(this ComboBox comboBox, string item)
        {
            var auto = new UIA3Automation();
            comboBox.Click();
            var itemtoselect = comboBox.FindFirstDescendant(auto.ConditionFactory.ByControlType(ControlType.ListItem).And(auto.ConditionFactory.ByName(item)));
           // itemtoselect.Click();            
           
            if (itemtoselect != null)
            {
                itemtoselect.Click();
            }

            Keyboard.Press(VirtualKeyShort.ESC);
        }

        /// <summary>
        /// Selects an option from a dropdown element by index
        /// </summary>
        /// <param name="comboBox"></param>
        /// <param name="index"></param>
        public static void SelectDropDownItem(this ComboBox comboBox, int index)
        {
            var ComboBoxElement = comboBox.AsComboBox().Select(index);
        }


        /// <summary>
        /// Selects radio button
        /// </summary>
        /// <param name="radioButton"></param>
        /// <param name="flag"></param>
        public static void Select(this RadioButton radioButton, bool flag)
        {
            var pattern = radioButton.Patterns.SelectionItem.Pattern;
            if (flag)
            {
                if (!pattern.IsSelected)
                    pattern.Select();
            }
            else
            {
                if (pattern.IsSelected)
                    pattern.RemoveFromSelection();
            }
        }

        /// <summary>
        /// Selects checkbox
        /// </summary>
        /// <param name="checkBox"></param>
        /// <param name="flag"></param>
        public static void Select(this CheckBox checkBox, bool flag)
        {
            var pattern = checkBox.Patterns.SelectionItem.Pattern;
            if (flag)
            {
                if (!pattern.IsSelected)
                    pattern.Select();
            }
            else
            {
                if (pattern.IsSelected)
                    pattern.RemoveFromSelection();
            }
        }

        //public static List<List<String>> GetData(this Grid grid, AutomationElement element)
        //{
        //    DataTable table = new DataTable();
        //    var table1 = element.FindFirstDescendant(x => x.ByAutomationId("")).AsTable();
        //    var table2 = window.FindFirstDescendant(cf => cf.ByAutomationId("tableId")).AsTable();

        //    foreach (var column in grid.)
        //    {

        //    }
        //    var rows = grid.RowCount;
        //    var columns = grid.ColumnCount;
        //    for (int row = 0; row < rows; row++)
        //    {
        //        for (int column = 0; column < columns; column++)
        //        {
        //            var cell =
        //        }
        //    }
        //}


        /// <summary>
        /// Scrolling down operation
        /// </summary>
        /// <param name="element"></param>
        /// <param name="scrollAmount"></param>
        public static void ScrollDown(this AutomationElement element, double scrollAmount = 100)
        {
            var pattern = element.Patterns.Scroll.PatternOrDefault;
            if (pattern != null && pattern.VerticallyScrollable)
            {
                var verticalScrollPercent = pattern.VerticalScrollPercent;
                while (verticalScrollPercent < scrollAmount)
                {
                    pattern.SetScrollPercent(0, scrollAmount);
                }
            }

        }

        /// <summary>
        /// Scrolling Up operation
        /// </summary>
        /// <param name="element"></param>
        /// <param name="scrollAmount"></param>
        public static void ScrollUp(this AutomationElement element, double scrollAmount = 100)
        {
            var pattern = element.Patterns.Scroll.PatternOrDefault;
            if (pattern != null && pattern.VerticallyScrollable)
            {
                var verticalScrollPercent = pattern.VerticalScrollPercent;
                while (verticalScrollPercent < scrollAmount)
                {
                    pattern.SetScrollPercent(scrollAmount, 0);
                }
            }

        }

        /// <summary>
        /// Scrolling Right operation
        /// </summary>
        /// <param name="element"></param>
        /// <param name="scrollAmount"></param>
        public static void ScrollRight(this AutomationElement element, double scrollAmount = 100)
        {
            var pattern = element.Patterns.Scroll.PatternOrDefault;
            if (pattern != null && pattern.HorizontallyScrollable)
            {
                var horizontalScrollPercent = pattern.HorizontalScrollPercent;
                while (horizontalScrollPercent < scrollAmount)
                {
                    pattern.SetScrollPercent(0,scrollAmount);
                }
            }

        }

        /// <summary>
        /// Scrolling left operation
        /// </summary>
        /// <param name="element"></param>
        /// <param name="scrollAmount"></param>
        public static void ScrollLeft(this AutomationElement element, double scrollAmount = 100)
        {
            var pattern = element.Patterns.Scroll.PatternOrDefault;
            if (pattern != null && pattern.HorizontallyScrollable)
            {
                var horizontalScrollPercent = pattern.HorizontalScrollPercent;
                while (horizontalScrollPercent < scrollAmount)
                {
                    pattern.SetScrollPercent(scrollAmount, 0);
                }
            }

        }

        /// <summary>
        /// Dragging from source and dropping to the destination
        /// </summary>
        /// <param name="SourceElement"></param>
        /// <param name="TargetElement"></param>
        public static void DrangAndDrop(this AutomationElement SourceElement, AutomationElement TargetElement)
        {
            var SourcePoint = SourceElement.Properties.ClickablePoint.Value;
            var TargetPoint = TargetElement.Properties.ClickablePoint.Value;
            Mouse.MoveTo(SourcePoint);
            Mouse.Down(MouseButton.Left);
            Mouse.MoveTo(TargetPoint);
            Mouse.Down(MouseButton.Left);
        }


        /// <summary>
        /// Window Maximize
        /// </summary>
        /// <param name="window"></param>
        public static void MaximizeWindow(this Window window)
        {
            window.Patterns.Window.Pattern.SetWindowVisualState(WindowVisualState.Maximized);
        }

        /// <summary>
        /// Uploads the file
        /// </summary>
        /// <param name="element"></param>
        /// <param name="window"></param>
        /// <param name="filePath"></param>
        public static void UploadFile(this AutomationElement element, Window window, string filePath)
        {
            element.Click();
            var dialog = element.FindFirstDescendant(x => x.ByControlType(ControlType.Window))?.AsWindow();
            dialog.WaitUntilClickable();
            var textbox = dialog.FindFirstDescendant(x => x.ByAutomationId("1148"))?.AsTextBox();
            textbox.Enter(filePath);
            var openbutton = dialog.FindFirstDescendant(x => x.ByAutomationId("1"))?.AsButton();
            openbutton.Click();
        }       

    }
}
