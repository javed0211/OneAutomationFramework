﻿using BoDi;
using FlaUI.Core;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Conditions;
using FlaUI.UIA2;
using FlaUI.UIA3;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using TechTalk.SpecFlow;

namespace OneAutomationFramework.Drivers.FlaUI
{
    public interface IFlaUIConfiguration
    {
        string? WinAppPath { get; }
        string? UserName { get; }
        string? Password { get; }
    }

    public class FlaUIConfiguration : IFlaUIConfiguration
    {
        private static Application application;
        public static Window mainwindow;
        public static ConditionFactory cf;

        private TestContext testContextInstance;

        private class FlaUIActionJson
        {
            [JsonInclude]
            public FlaUISpecflowJson FlaUI { get; private set; } = new FlaUISpecflowJson();
        }

        private class FlaUISpecflowJson
        {
            [JsonInclude]
            public string? WinAppPath { get; private set; }

            [JsonInclude]
            public string? UserName { get; private set; }

            [JsonInclude]
            public string? Password { get; private set; }
        }

        private readonly Lazy<FlaUIActionJson> _flaUIJsonPart;

        private FlaUIActionJson LoadSpecFlowJson()
        {
            var json = Load();

            if (string.IsNullOrWhiteSpace(json))
            {
                return new FlaUIActionJson();
            }

            var jsonSerializerOptions = new JsonSerializerOptions()
            {
                PropertyNameCaseInsensitive = true
            };

            jsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());

            var flaUIActionConfig = System.Text.Json.JsonSerializer.Deserialize<FlaUIActionJson>(json, jsonSerializerOptions);

            return flaUIActionConfig ?? new FlaUIActionJson();

        }

        public FlaUIConfiguration(IObjectContainer objectContainer)
        {
            _flaUIJsonPart = new Lazy<FlaUIActionJson>(LoadSpecFlowJson);
            cf = new ConditionFactory(new UIA2PropertyLibrary());
        }

        public string? WinAppPath => _flaUIJsonPart.Value.FlaUI.WinAppPath;
        public string? UserName => _flaUIJsonPart.Value.FlaUI.UserName;
        public string? Password => _flaUIJsonPart.Value.FlaUI.Password;

        private string? GetFilePathToConfigurationFile(string configurationFileName)
        {
            if (AppDomain.CurrentDomain.BaseDirectory is not null)
            {
                var FlaUIJsonFileInAppDomainBaseDirectory =
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, configurationFileName);

                if (File.Exists(FlaUIJsonFileInAppDomainBaseDirectory))
                {
                    return FlaUIJsonFileInAppDomainBaseDirectory;
                }

                var FlaUIJsonFileTwoDirectoriesUp =
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", configurationFileName);

                if (File.Exists(FlaUIJsonFileTwoDirectoriesUp))
                {
                    return FlaUIJsonFileTwoDirectoriesUp;
                }
            }

            var FlaUIJsonFileInCurrentDirectory = Path.Combine(Environment.CurrentDirectory, configurationFileName);

            if (File.Exists(FlaUIJsonFileInCurrentDirectory))
            {
                return FlaUIJsonFileInCurrentDirectory;
            }

            return null;
        }

        public string Load()
        {
            var FlaUIJsonFilePath = GetFilePathToConfigurationFile("FlaUIConfig.json");

            if (FlaUIJsonFilePath != null)
            {
                var content = File.ReadAllText(FlaUIJsonFilePath);

                return content;
            }

            return "{}";
        }

        public dynamic LoadJson()
        {
            var FlaUIJsonFilePath = GetFilePathToConfigurationFile("FlaUIConfig.json");
            var content = File.ReadAllText(FlaUIJsonFilePath);
            return JsonConvert.DeserializeObject(content);
        }

        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


    }



}
