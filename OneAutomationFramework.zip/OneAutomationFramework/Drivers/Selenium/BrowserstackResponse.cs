﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OneAutomationFramework.Drivers
{ 
    public class BrowserstackResponse
    {
        public string os { get; set; }
        public string os_version { get; set; }
        public string browser { get; set; }
        public string device { get; set; }
        public string browser_version { get; set; }
        public bool? real_mobile { get; set; }

    }

    public class AppUpload
    {
        public string app_url { get; set; }
    }

}
