﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace OneAutomationFramework.Drivers.Selenium
{
    public interface ISeleniumConfiguration
    {
        Browser Browser { get; }

        string[]? Arguments { get; }

        float? DefaultTimeout { get; }

        bool? Headless { get; }

        float? SlowMo { get; }

        string? TraceDir { get; }

        bool? runOnBrowserstack { get; }

        string? userKey { get; }

        string? accessToken { get; }
        
        bool? privateMode { get; }

        bool? local { get; }

        string? build { get; }

        string? device { get; }

        string? os { get; }
        string? osVersion { get; }
        string? bsBrowser { get; }
        string? bsbrowserVersion { get; }

        string? projectName { get; }

        string? SeleniumVersion { get; }

        string? Env { get; }
        string? EnvUrl { get; }
    }

    public class SeleniumConfiguration : ISeleniumConfiguration
    {
        private class SpecFlowActionJson
        {
            [JsonInclude]
            public SeleniumSpecFlowJsonPart Selenium { get; private set; } = new SeleniumSpecFlowJsonPart();
        }

        private class SeleniumSpecFlowJsonPart
        {
            [JsonInclude]
            public Browser Browser { get; private set; }

            [JsonInclude]
            public string[]? Arguments { get; private set; }

            [JsonInclude]
            public float? DefaultTimeout { get; private set; }

            [JsonInclude]
            public bool? Headless { get; private set; }

            [JsonInclude]
            public float? SlowMo { get; private set; }

            [JsonInclude]
            public string? TraceDir { get; private set; }

            [JsonInclude]
            public bool? runOnBrowserstack { get; private set; }

            [JsonInclude]
            public string? userKey { get; private set; }

            [JsonInclude]
            public string? accessToken { get; private set; }

            [JsonInclude]
            public bool? local { get; private set; }

            [JsonInclude]
            public string? build { get; private set; }

            [JsonInclude]
            public string? device { get; private set; }

            [JsonInclude]
            public string? os { get; private set; }

            [JsonInclude]
            public string? osVersion { get; private set; }

            [JsonInclude]
            public string? bsBrowser { get; private set; }

            [JsonInclude]
            public string? browserVersion { get; private set; }

            [JsonInclude]
            public bool? privateMode { get; private set; }

            [JsonInclude]
            public string? projectName { get; private set; }

            [JsonInclude]
            public string? SeleniumVersion { get; private set; }

            [JsonInclude]
            public string? Env { get; private set; }
            [JsonInclude]
            public string? EnvUrl { get; private set; }

        }

        private readonly Lazy<SpecFlowActionJson> _specflowJsonPart;

        private SpecFlowActionJson LoadSpecFlowJson()
        {
            var json = Load();

            if (string.IsNullOrWhiteSpace(json))
            {
                return new SpecFlowActionJson();
            }

            var jsonSerializerOptions = new JsonSerializerOptions()
            {
                PropertyNameCaseInsensitive = true
            };

            jsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());

            var specflowActionConfig = System.Text.Json.JsonSerializer.Deserialize<SpecFlowActionJson>(json, jsonSerializerOptions);

            return specflowActionConfig ?? new SpecFlowActionJson();
        }

        /// <summary>
        /// Provides the configuration details for the Selenium instance
        /// </summary>
        /// <param name="specFlowActionJsonLoader"></param>
        public SeleniumConfiguration()
        {
            _specflowJsonPart = new Lazy<SpecFlowActionJson>(LoadSpecFlowJson);
        }

        /// <summary>
        /// The browser specified in the configuration
        /// </summary>
        public Browser Browser => _specflowJsonPart.Value.Selenium.Browser;

        /// <summary>
        /// Additional arguments used when launching the browser
        /// </summary>
        public string[]? Arguments => _specflowJsonPart.Value.Selenium.Arguments;

        /// <summary>
        /// The default timeout used to configure the browser
        /// </summary>
        public float? DefaultTimeout => _specflowJsonPart.Value.Selenium.DefaultTimeout;

        /// <summary>
        /// Whether the browser should launch headless
        /// </summary>
        public bool? Headless => _specflowJsonPart.Value.Selenium.Headless;

        /// <summary>
        /// How many miliseconds elapse between every action 
        /// </summary>
        public float? SlowMo => _specflowJsonPart.Value.Selenium.SlowMo;

        /// <summary>
        /// If specified, traces are saved into this directory 
        /// </summary>
        public string? TraceDir => _specflowJsonPart.Value.Selenium.TraceDir;

        /// <summary>
        /// Whether the browser should runon browsertack
        /// </summary>
        public bool? runOnBrowserstack => _specflowJsonPart.Value.Selenium.runOnBrowserstack;
        /// <summary>
        /// Whether the browser should runon browsertack
        /// </summary>

        public string? userKey => _specflowJsonPart.Value.Selenium.userKey;
        /// <summary>
        /// Whether the browser should runon browsertack
        /// </summary>
        public string? accessToken => _specflowJsonPart.Value.Selenium.accessToken;
        /// <summary>
        /// Whether the browser should runon browsertack
        /// </summary>
        public bool? local => _specflowJsonPart.Value.Selenium.local;

        /// <summary>
        /// Whether the browser should runon browsertack
        /// </summary>
        public string? build => _specflowJsonPart.Value.Selenium.build;

        public string? device => _specflowJsonPart.Value.Selenium.device;

        public string? os => _specflowJsonPart.Value.Selenium.os;

        public string? osVersion => _specflowJsonPart.Value.Selenium.osVersion;

        public string? bsBrowser => _specflowJsonPart.Value.Selenium.bsBrowser;

        public string? bsbrowserVersion => _specflowJsonPart.Value.Selenium.browserVersion;

        public bool? privateMode => _specflowJsonPart.Value.Selenium.privateMode;

        public string? projectName => _specflowJsonPart.Value.Selenium.projectName;

        public string? SeleniumVersion => _specflowJsonPart.Value.Selenium.SeleniumVersion;
        public string? Env => _specflowJsonPart.Value.Selenium.Env;
        public string? EnvUrl => _specflowJsonPart.Value.Selenium.EnvUrl;

        private string? GetFilePathToConfigurationFile(string configurationFileName)
        {
            if (AppDomain.CurrentDomain.BaseDirectory is not null)
            {
                var specflowJsonFileInAppDomainBaseDirectory =
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, configurationFileName);

                if (File.Exists(specflowJsonFileInAppDomainBaseDirectory))
                {
                    return specflowJsonFileInAppDomainBaseDirectory;
                }

                var specflowJsonFileTwoDirectoriesUp =
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", configurationFileName);

                if (File.Exists(specflowJsonFileTwoDirectoriesUp))
                {
                    return specflowJsonFileTwoDirectoriesUp;
                }
            }

            var specflowJsonFileInCurrentDirectory = Path.Combine(Environment.CurrentDirectory, configurationFileName);

            if (File.Exists(specflowJsonFileInCurrentDirectory))
            {
                return specflowJsonFileInCurrentDirectory;
            }

            return null;
        }

        public string Load()
        {
            var specFlowJsonFilePath = GetFilePathToConfigurationFile("SeleniumConfig.json");

            if (specFlowJsonFilePath != null)
            {
                var content = File.ReadAllText(specFlowJsonFilePath);

                return content;
            }

            return "{}";
        }

        public dynamic LoadJson()
        {
            var specFlowJsonFilePath = GetFilePathToConfigurationFile("SeleniumConfigconfig.json");
            var content = File.ReadAllText(specFlowJsonFilePath);
            return JsonConvert.DeserializeObject(content);

        }
    }
   
}