﻿using LoggerLibrary;
using Newtonsoft.Json;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Safari;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace OneAutomationFramework.Drivers.Selenium
{
    /// <summary>
    /// Manages a browser instance using Selenium
    /// </summary>
    public class SeleniumDriver : IDisposable
    {
        private readonly ISeleniumConfiguration _seleniumConfiguration;
        private readonly IDriverInitialiser _driverInitialiser;
        protected readonly AsyncLazy<IWebDriver> _currentBrowserLazy;
        public ScenarioContext _scenarioContext;
        protected bool _isDisposed;

        public SeleniumDriver(ISeleniumConfiguration seleniumConfiguration, IDriverInitialiser driverInitialiser, ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
            _seleniumConfiguration = seleniumConfiguration;
            _driverInitialiser = driverInitialiser;
            if (_currentBrowserLazy == null)
                _currentBrowserLazy = new AsyncLazy<IWebDriver>(CreateSeleniumDriver);
        }

        /// <summary>
        /// The current Selenium instance
        /// </summary>
        public IWebDriver Current => _currentBrowserLazy.Value.Result;

        /// <summary>
        /// Creates a new instance of Playwright (opens a browser)
        /// </summary>
        /// <returns></returns>
        public IWebDriver CreateSeleniumDriver()
        {
            dynamic options = null;
            IWebDriver driver = null;
            dynamic capabilities = null;
            var browserstackOptions = new Dictionary<string, object>();
            if (_seleniumConfiguration.runOnBrowserstack.Value)
            {
                try
                {
                    Logger.Info("Creating driver to run on browserstack");
                    if (_seleniumConfiguration.SeleniumVersion != "3.141")
                    {
                        browserstackOptions = GetBrowserstackCapabilities();
                        options = GetBrowserOptions(_seleniumConfiguration.bsBrowser);
                        if (_seleniumConfiguration.os.ToLower() != "ios")
                            options.AddArguments(_seleniumConfiguration.Arguments ?? new string[] { });
                        options.AddAdditionalOption("bstack:options", browserstackOptions);
                        Logger.Info("Added capabilities/options for browserstack driver based on selenium version");
                    }
                    else
                    {
                        capabilities = GetBrowserstackCapabilities();
                        Logger.Info("Added capabilities/options for browserstack driver based on selenium version");
                    }
                }
                catch (Exception e)
                {
                    Logger.Error("Unable to add capability due to " + e.Message);
                }
            }
            try
            {
                return _seleniumConfiguration.Browser switch
                {
                    Browser.Chrome => _driverInitialiser.GetChromeDriver(_seleniumConfiguration.os, _seleniumConfiguration.bsbrowserVersion, _seleniumConfiguration.privateMode, _seleniumConfiguration.Arguments, _seleniumConfiguration.DefaultTimeout, _seleniumConfiguration.Headless),
                    Browser.Firefox => _driverInitialiser.GetFirefoxDriver(_seleniumConfiguration.os, _seleniumConfiguration.bsbrowserVersion, _seleniumConfiguration.privateMode, _seleniumConfiguration.Arguments, _seleniumConfiguration.DefaultTimeout, _seleniumConfiguration.Headless),
                    Browser.Edge => _driverInitialiser.GetEdgeDriver(_seleniumConfiguration.os, _seleniumConfiguration.bsbrowserVersion, _seleniumConfiguration.privateMode, _seleniumConfiguration.Arguments, _seleniumConfiguration.DefaultTimeout, _seleniumConfiguration.Headless),
                    Browser.Browserstack => _driverInitialiser.GetBrowserstackDriver(options != null ? options : capabilities),
                    _ => throw new NotImplementedException($"Support for browser {_seleniumConfiguration.Browser} is not implemented yet"),
                };
            }
            catch (Exception e)
            {
                Logger.Error("Unable to return browser driver due to " + e.Message);
                throw;

            }
        }

        /// <summary>
        /// Disposes the Selenium instance (closing the browser)
        /// </summary>
        public void Dispose()
        {
            if (_isDisposed)
            {
                return;
            }

            if (_currentBrowserLazy.IsValueCreated)
            {
                Task.Run(async delegate
                {
                    Current.Close();
                    Current.Dispose();
                });
            }
            _isDisposed = true;
        }

        public static List<BrowserstackResponse> GetDevicesList()
        {
            Logger.Info("Getting available device list from browserstack");
            using (var httpClient = new HttpClient())
            {
                using (var request = new HttpRequestMessage(new HttpMethod("GET"), "https://api.browserstack.com/automate/browsers.json"))
                {
                    var base64authorization = Convert.ToBase64String(Encoding.ASCII.GetBytes("sivasikkan_RCYJK8:QaRYmqKNfUv46jcjgXv6"));
                    request.Headers.TryAddWithoutValidation("Authorization", $"Basic {base64authorization}");

                    var response = httpClient.SendAsync(request).Result;
                    if (response != null)
                    {
                        Logger.Info("Returned available device list from browserstack");
                    }
                    else
                    {
                        Logger.Error("Returned empty device list from browserstack");
                    }
                    return JsonConvert.DeserializeObject<List<BrowserstackResponse>>(response.Content.ReadAsStringAsync().Result);
                }
            }
        }

        public dynamic GetBrowserstackCapabilities()
        {
            Logger.Info("Getting browserstack capabilities/options.");
            var browserstackOptions = new Dictionary<string, object>();
            var deviceList = GetDevicesList();
            if (_seleniumConfiguration.device != null)
            {
                try
                {
                    Logger.Info("Adding capabilties when device is not null in SeleniumConfig." + "\n" + "Device name: " + _seleniumConfiguration.device);
                    var deviceCap = deviceList.Where(x => x.device != null).Where(x => x.device.ToLower() == _seleniumConfiguration.device.ToLower() && x.os_version.ToLower() == _seleniumConfiguration.osVersion.ToLower() && x.browser.ToLower() == _seleniumConfiguration.bsBrowser.ToLower()).FirstOrDefault();
                    if (deviceCap == null)
                        deviceCap = deviceList.Where(x => x.device != null).Where(x => x.device.ToLower() == _seleniumConfiguration.device.ToLower()).FirstOrDefault();
                    browserstackOptions.Add("deviceName", deviceCap.device);
                    browserstackOptions.Add("os", deviceCap.os);
                    browserstackOptions.Add("osVersion", deviceCap.os_version);
                    browserstackOptions.Add("browserVersion", "latest");
                    browserstackOptions.Add("browserName", deviceCap.browser);
                    browserstackOptions.Add("realMobile", "true");
                    browserstackOptions.Add("local", _seleniumConfiguration.local);
                    browserstackOptions.Add("seleniumVersion", "4.8.0");
                    browserstackOptions.Add("userName", _seleniumConfiguration.userKey);
                    browserstackOptions.Add("accessKey", _seleniumConfiguration.accessToken);
                    browserstackOptions.Add("sessionName", _scenarioContext.ScenarioInfo.Title);
                    if (Environment.GetEnvironmentVariable("BROWSERSTACK_BUILD_NAME") != null)
                        browserstackOptions.Add("buildName", Environment.GetEnvironmentVariable("BROWSERSTACK_BUILD_NAME"));
                    else
                        browserstackOptions.Add("buildName", _seleniumConfiguration.projectName + DateTime.Now);
                    browserstackOptions.Add("projectName", _seleniumConfiguration.projectName);
                    browserstackOptions.Add("debug", "true");

                }
                catch (Exception ex)
                {
                    Logger.Error("Adding capabilities failed due to " + ex.Message + " for device " + _seleniumConfiguration.device);
                }
                Logger.Info("Adding capabilities for device " + _seleniumConfiguration.device + " is successfull");
                return browserstackOptions;
            }
            else
            {
                Logger.Info("Adding capabilties when device is null in SeleniumConfig." + "\n" + "OS : " + _seleniumConfiguration.os);
                try
                {
                    var deviceCap = deviceList.Where(x => x.device == null).Where(x => x.os.ToLower() == _seleniumConfiguration.os.ToLower() && x.os_version == _seleniumConfiguration.osVersion).FirstOrDefault();
                    if (deviceCap == null)
                        deviceCap = deviceList.Where(x => x.device == null).Where(x => x.os.ToLower() == _seleniumConfiguration.os.ToLower()).FirstOrDefault();
                    browserstackOptions.Add("os", deviceCap.os);
                    browserstackOptions.Add("osVersion", deviceCap.os_version);
                    browserstackOptions.Add("browserVersion", "latest");
                    browserstackOptions.Add("browserName", _seleniumConfiguration.bsBrowser);
                    //browserstackOptions.Add("realMobile", "true");
                    browserstackOptions.Add("local", _seleniumConfiguration.local);
                    browserstackOptions.Add("seleniumVersion", "4.8.0");
                    browserstackOptions.Add("userName", _seleniumConfiguration.userKey);
                    browserstackOptions.Add("accessKey", _seleniumConfiguration.accessToken);
                    browserstackOptions.Add("sessionName", _scenarioContext.ScenarioInfo.Title);
                    if (Environment.GetEnvironmentVariable("BROWSERSTACK_BUILD_NAME") != null)
                        browserstackOptions.Add("buildName", Environment.GetEnvironmentVariable("BROWSERSTACK_BUILD_NAME"));
                    else
                        browserstackOptions.Add("buildName", _seleniumConfiguration.projectName + DateTime.Now);
                    browserstackOptions.Add("projectName", _seleniumConfiguration.projectName);
                    browserstackOptions.Add("debug", "true");
                }
                catch (Exception ex) { Logger.Error("Adding capabilites to browserstack available dvice failed due to " + ex.Message); }
                Logger.Info("Adding capabilities to browserstack available device is successfull");
                return browserstackOptions;
            }
        }

        public static dynamic GetBrowserOptions(string browser)
        {
            Logger.Info("Getting browser options for" + browser);
            try
            {
                return browser.ToLower() switch
                {
                    "chrome" => new ChromeOptions(),
                    "firefox" => new FirefoxOptions(),
                    "edge" => new EdgeOptions(),
                    "safari" => new SafariOptions(),
                    "iphone" => new SafariOptions(),
                    "android" => new ChromeOptions(),
                    _ => throw new NotImplementedException($"Support for browser {browser} is not implemented yet"),
                };
            }
            catch (Exception e)
            {
                Logger.Error("Unable to get browser option due to " + e.Message);
                throw;
            }
        }
    }
}
