﻿
using FlaUI.Core;
using FlaUI.Core.AutomationElements;
using FlaUI.UIA3;
using OneAutomationFramework.Drivers.FlaUI;
using System.Threading;
using TechTalk.SpecFlow;
using static OneAutomationFramework.Drivers.FlaUI.FlaUIConfiguration;

namespace OneAutomationFramework.Steps
{
    [Binding]
    public sealed class Steps
    {
        // For additional details on SpecFlow step definitions see https://go.specflow.org/doc-stepdef

        private readonly ScenarioContext _scenarioContext;
        private readonly FlaUIDriver _flaUIDriver;

        public Steps(ScenarioContext scenarioContext, FlaUIDriver flaUIDriver)
        {
            _scenarioContext = scenarioContext;
            _flaUIDriver = flaUIDriver;

        }

        [Given(@"Selenium driver is created")]
        public void GivenSeleniumDriverIsCreated()
        {

        }

        [Given(@"I launch the Win application")]
        public void GivenILaunchTheWinApplication()
        {            
            var window = _flaUIDriver.Current.GetMainWindow(new UIA3Automation());
            //var mainwindow=_flaUIDriver.GetMainWindow();
            window.MaximizeWindow();

            var txtbx = window.FindFirstDescendant(cf.ByAutomationId("TextBox")).AsTextBox();
            txtbx.TypeText("abcd");

            var checkbox = window.FindFirstDescendant(cf.ByAutomationId("SimpleCheckBox")).AsCheckBox();
            checkbox.Click();

            var radio = window.FindFirstDescendant(cf.ByAutomationId("RadioButton1")).AsRadioButton();
            radio.Select(true);

          

            var dateTimePicker1 = window.FindFirstDescendant(cf.ByAutomationId("dateTimePicker1"));
            dateTimePicker1.ClickElement();

            

            var dropdown = window.FindFirstDescendant(cf.ByAutomationId("NonEditableCombo")).AsComboBox();
            dropdown.SelectDropdownItem("Item 2");
            dropdown.SelectDropdownItem("Item 3");
            dropdown.SelectDropdownItem("Item 4");


            var contextmenu = window.FindFirstDescendant(cf.ByName("ContextMenu"));
            contextmenu.xtRightClick();

            Thread.Sleep(3000);
            
            _flaUIDriver.Dispose();
           //_flaUIDriver.Current.Dispose();

        }
    }
}
