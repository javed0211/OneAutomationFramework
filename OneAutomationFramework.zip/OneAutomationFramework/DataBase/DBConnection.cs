﻿using LoggerLibrary;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data.SqlClient;


namespace OneAutomationFramework.DataBase
{
    //public interface IDBConnection
    //{
    //  //  SqlConnection GetSqlConnection(string serverName, string dbName, string userName, string password);
    // //   SqlConnection GetSqlConnection(string connectionString);
    //   // OracleConnection GetOracleConnection(string connectionString);
    //  //  OracleConnection GetOracleConnection(string serverName, string dbName, string userName, string password);
    //    //OracleConnection GetOracleConnection(string username, string password, string server, string port, string SID);
    //}

    public class DBConnection
    {
        IDataBaseConfiguration _dataBaseConfiguration;

        public DBConnection(IDataBaseConfiguration dataBaseConfiguration)
        {
            _dataBaseConfiguration = dataBaseConfiguration;

        }
        /// <summary>
        /// Creates connection to Db, based on connectionType(ConnectionString or ConnectionStringConfig)
        /// passed in DatabaseConfig.json
        /// </summary>
        /// <typeparam name="T">Type of connection(SQL or Oracle)</typeparam>
        /// <returns>Open Db connection</returns>
        public T GetConnection<T>()
        {
            return _dataBaseConfiguration.connectionType switch
            {
                "ConnectionString" => GetConnectionFromConnectionString<T>(),
                "ConnectionStringConfig" => GetConnectionFromConnectionConfig<T>()
            };
        }
        /// <summary>
        /// This method closes DB connection
        /// </summary>
        /// <typeparam name="T">Type of connection</typeparam>
        /// <param name="conn"></param>
        /// <exception cref="NotImplementedException"></exception>
        public void CloseConnection<T>(T conn)
        {
            //var c = test.GetType();
            var c = conn?.GetType().Name switch
            {
                "OracleConnection" => CloseOracleConnection((OracleConnection)Convert.ChangeType(conn, typeof(OracleConnection))),
                "SqlConnection" => CloseSqlConnection((SqlConnection)Convert.ChangeType(conn, typeof(SqlConnection))),
                //  "NpgsqlConnection" => ClosePostgreConnection((NpgsqlConnection)Convert.ChangeType(test, typeof(NpgsqlConnection))),
                _ => throw new NotImplementedException($"Support for database {_dataBaseConfiguration.dbType} is not implemented yet")
            };
        }
        /// <summary>
        /// Creats Db connection from connection string,when
        ///  "connectionType"is set to "ConnectionString" in DatabaseConfig.json
        /// </summary>
        /// <typeparam name="T">Type of connection</typeparam>
        /// <returns>Open conenction</returns>
        /// <exception cref="NotImplementedException"></exception>
        private T GetConnectionFromConnectionString<T>()
        {
            return _dataBaseConfiguration.dbType switch
            {
                "Oracle" => (T)Convert.ChangeType((GetOracleConnection(_dataBaseConfiguration.connectionString)), typeof(T)),
                "MySQL" => (T)Convert.ChangeType(GetSqlConnection(_dataBaseConfiguration.connectionString), typeof(T)),
                // "Postgre"=>(T)Convert.ChangeType(GetNpgsqlConnection(_dataBaseConfiguration.connectionString), typeof(T)),
                _ => throw new NotImplementedException($"Support for database {_dataBaseConfiguration.dbType} is not implemented yet"),
            };
        }
        /// <summary>
        /// This methods first creates connection string 
        /// when  "connectionType" is set to  "ConnectionStringConfig"
        ///in DatabaseConfig.json and then creates a new db connection.
        ///  "connectionType": "ConnectionStringConfig",
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        private T GetConnectionFromConnectionConfig<T>()
        {
            return _dataBaseConfiguration.dbType switch
            {
                "Oracle" => (T)Convert.ChangeType(GetOracleConnection(ConnectionStringBuilder()), typeof(T)),
                "MySQL" => (T)Convert.ChangeType(GetSqlConnection(ConnectionStringBuilder()), typeof(T)),
                _ => throw new NotImplementedException($"Support for database {_dataBaseConfiguration.dbType} is not implemented yet"),
            };

        }
        /// <summary>
        /// Method creates connection string when "connectionType" is "ConnectionStringConfig"
        /// in DatabaseConfig.json
        /// Connection string is based on DbType mentioned in DatabaseConfig.json
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        private string ConnectionStringBuilder()
        {
            //"Data Source=" + serverName + ";Initial Catalog=" + dbName + ";User ID = " + userName + "; Password = " + password;
            // "USER ID=" + userName + ";PASSWORD=" + password + ";DATA SOURCE=" + serverName;
            //String.Format("User Id = {0} ; Password = {1}; Data Source = (DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = {2})(PORT = {3}))(CONNECT_DATA = (SID = {4})))", username, password, server, port, SID);
            return _dataBaseConfiguration.dbType switch
            {
                "Oracle" => GetUserNameParam() + ";" + GetUserPasswordParam() + ";" + ";" + GetDbSourceParam(),
                "MySQL" => GetDbSourceParam() + ";" + GetDbNameParam() + ";" + GetUserNameParam() + ";" + GetUserPasswordParam(),
                _ => throw new NotImplementedException($"Support for database {_dataBaseConfiguration.dbType} is not implemented yet"),
            };
        }
        /// <summary>
        /// Return username param based on db type
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        private string GetUserNameParam()
        {
            return _dataBaseConfiguration.dbType switch
            {
                "MySQL" => "User ID = " + _dataBaseConfiguration.userName,
                "Oracle" => "USER ID=" + _dataBaseConfiguration.userName,
                _ => throw new NotImplementedException($"Please provide user id in DataBaseConfig"),
            };

        }
        /// <summary>
        /// return password param based on DbType
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        private string GetUserPasswordParam()
        {
            return _dataBaseConfiguration.dbType switch
            {
                "Oracle" => "PASSWORD=" + _dataBaseConfiguration.password,
                "MySQL" => "Password = " + _dataBaseConfiguration.password,
                _ => throw new NotImplementedException($"Please provide password in DataBaseConfig"),
            };
        }
        /// <summary>
        /// return db name param
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        private string GetDbNameParam()
        {
            return _dataBaseConfiguration.dbType switch
            {
                "Oracle" => "",
                "MySQL" => "Initial Catalog=" + _dataBaseConfiguration.database,
                _ => throw new NotImplementedException($"Please provide database name in DataBaseConfig"),
            };
        }
        /// <summary>
        /// return db source
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        private string GetDbSourceParam()
        {

            return _dataBaseConfiguration.dbType switch
            {
                "Oracle" => (_dataBaseConfiguration.dataSourceDescriptor ? String.Format("Data Source = (DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = {2})(PORT = {3}))(CONNECT_DATA = (SID = {4})))", _dataBaseConfiguration.database, _dataBaseConfiguration.port, _dataBaseConfiguration.sid)
                : "DATA SOURCE=" + _dataBaseConfiguration.database),
                "MySQL" => "Data Source=" + _dataBaseConfiguration.dataSource,
                _ => throw new NotImplementedException($"Please provide database name in DataBaseConfig"),
            };
        }
        //
        // Summary:
        //     Initializes a new instance of the System.Data.SqlClient.SqlConnection class when
        //     given a string that contains the connection string.
        //
        // Parameters:
        //   connectionString:
        //     The connection used to open the SQL Server database.
        private SqlConnection GetSqlConnection(string connectionString)
        {
            try
            {
                Logger.Info("Creating SQL connection");
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                Logger.Info("SQL connection is successfull");
                return conn;
            }
            catch (Exception e)
            {
                Logger.Error("SQL connection is failed");
                throw;
            }
        }
        //
        // Summary:
        //     Initializes a new instance of the OracleConnetion class when
        //     given a string that contains the connection string.
        //
        // Parameters:
        //   connectionString:
        //     The connection used to open the SQL Server database.
        private OracleConnection GetOracleConnection(string connectionString)
        {
            try
            {
                Logger.Info("Creating oracle connection");
                OracleConnection conn = new OracleConnection(connectionString);
                conn.Open();
                Logger.Info("Oracle connection is successfull");
                return conn;
            }
            catch (Exception e)
            {
                Logger.Info("Oracle connection is failed");
                throw e;
            }
        }
        //
        // Summary:
        //     Closes the connection to the database. This is the preferred method of closing
        //     any open connection.
        //
        // Exceptions:
        //   T:System.Data.SqlClient.SqlException:
        //     The connection-level error that occurred while opening the connection.
        private bool CloseSqlConnection(SqlConnection connection)
        {
            try
            {
                Logger.Info("Closing SQL connection");
                connection.Dispose();
                connection.Close();
                Logger.Info("SQL connection closed");
                return true;
            }
            catch (Exception e)
            {
                Logger.Error("Unable to close oracle connection due to" + e.Message);
                throw;
            }
        }
        //
        // Summary:
        //     Closes the connection to the database. This is the preferred method of closing
        //     any open connection.
        //
        private bool CloseOracleConnection(OracleConnection connection)
        {
            try
            {
                Logger.Info("Closing oracle connection");
                connection.Dispose();
                connection.Close();
                Logger.Info("SQL connection closed");
                return true;
            }
            catch (Exception e)
            {
                Logger.Error("Unable to close oracle connection due to " + e.Message);
                throw;
            }

        }
        // private string 
    }

}
