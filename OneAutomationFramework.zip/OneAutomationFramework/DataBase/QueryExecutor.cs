﻿using LoggerLibrary;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Data.SqlClient;

namespace OneAutomationFramework.DataBase
{
    public class QueryExecutor
    {
        IDataBaseConfiguration _dataBaseConfiguration;

        public QueryExecutor(IDataBaseConfiguration dataBaseConfiguration)
        {
            _dataBaseConfiguration = dataBaseConfiguration;

        }
        /// <summary>
        /// Executes select query for SQL or oracle and returns datatable 
        /// </summary>
        /// <typeparam name="T">Type of connection</typeparam>
        /// <param name="conn">db connection</param>
        /// <param name="query">Select query</param>
        /// <returns>DataTable</returns>
        /// <exception cref="NotImplementedException"></exception>
        public DataTable GetQuery<T>(T conn, string query)
        {
            try
            {
                return conn?.GetType().Name switch
                {
                    "OracleConnection" => OracleGetQuery((OracleConnection)Convert.ChangeType(conn, typeof(OracleConnection)), query),
                    "SqlConnection" => SqlGetQuery((SqlConnection)Convert.ChangeType(conn, typeof(SqlConnection)), query),
                    //  "NpgsqlConnection" => ClosePostgreConnection((NpgsqlConnection)Convert.ChangeType(test, typeof(NpgsqlConnection))),
                    _ => throw new NotImplementedException($"Support for database {_dataBaseConfiguration.dbType} is not implemented yet")
                };
            }
            catch (Exception e)
            {
                Logger.Error("Get query failed due to " + e.Message);
                throw;
            }
        }
        /// <summary>
        /// Executes inser query for SQL or Oracle Db
        /// </summary>
        /// <typeparam name="T">Type of connection</typeparam>
        /// <param name="conn">Open connection</param>
        /// <param name="query">Query to inset</param>
        /// <exception cref="NotImplementedException"></exception>
        public void InsertQuery<T>(T conn, string query)
        {
            try
            {
                var res = conn?.GetType().Name switch
                {
                    "OracleConnection" => OracleInsertQuery((OracleConnection)Convert.ChangeType(conn, typeof(OracleConnection)), query),
                    "SqlConnection" => SqlInsertQuery((SqlConnection)Convert.ChangeType(conn, typeof(SqlConnection)), query),
                    //  "NpgsqlConnection" => ClosePostgreConnection((NpgsqlConnection)Convert.ChangeType(test, typeof(NpgsqlConnection))),
                    _ => throw new NotImplementedException($"Support for database {_dataBaseConfiguration.dbType} is not implemented yet")
                };
            }
            catch (Exception e)
            {
                Logger.Error("Insert query failed due to " + e.Message);
                throw;
            }
        }
        /// <summary>
        /// Executes delete command for SQL or Oracle Db
        /// </summary>
        /// <typeparam name="T">Type of conenction</typeparam>
        /// <param name="conn">open connection</param>
        /// <param name="query">delete query</param>
        /// <exception cref="NotImplementedException"></exception>
        public void DeleteQuery<T>(T conn, string query)
        {
            try
            {
                var res = conn?.GetType().Name switch
                {
                    "OracleConnection" => OracleDeleteQuery((OracleConnection)Convert.ChangeType(conn, typeof(OracleConnection)), query),
                    "SqlConnection" => SqlDeleteQuery((SqlConnection)Convert.ChangeType(conn, typeof(SqlConnection)), query),
                    //  "NpgsqlConnection" => ClosePostgreConnection((NpgsqlConnection)Convert.ChangeType(test, typeof(NpgsqlConnection))),
                    _ => throw new NotImplementedException($"Support for database {_dataBaseConfiguration.dbType} is not implemented yet")
                };
            }
            catch (Exception e)
            {
                Logger.Error("Delete query failed due to " + e.Message);
                throw;
            }
        }
        /// <summary>
        /// Get stored procedure form SQL or Oracle db
        /// </summary>
        /// <typeparam name="T">Type of connection</typeparam>
        /// <param name="conn">open connection</param>
        /// <param name="procedurename">name of procedure to be fetched</param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public DataTable GetStoredProcedure<T>(T conn, string procedurename)
        {
            try
            {
                return conn?.GetType().Name switch
                {
                    "OracleConnection" => GetOracleStoredProcedure((OracleConnection)Convert.ChangeType(conn, typeof(OracleConnection)), procedurename),
                    "SqlConnection" => GetSqlStoredProcedure((SqlConnection)Convert.ChangeType(conn, typeof(SqlConnection)), procedurename),
                    //  "NpgsqlConnection" => ClosePostgreConnection((NpgsqlConnection)Convert.ChangeType(test, typeof(NpgsqlConnection))),
                    _ => throw new NotImplementedException($"Support for database {_dataBaseConfiguration.dbType} is not implemented yet")
                };
            }
            catch (Exception e)
            {
                Logger.Error("Failed to get stored procedure due to " + e.Message);
                throw;
            }
        }
        /// <summary>
        /// Executes delete oracle command
        /// </summary>
        /// <param name="connection">OracleConnection</param>
        /// <param name="query">Delete query</param>
        /// <returns>true after deletion</returns>
        private bool OracleDeleteQuery(OracleConnection connection, string query)
        {
            try
            {
                OracleDataAdapter adapter = new OracleDataAdapter();
                adapter.InsertCommand = new OracleCommand(query, connection);
                adapter.InsertCommand.ExecuteNonQuery();
                adapter.Dispose();
                Logger.Info("Successfully executed Oracle delete query");
                return true;
            }
            catch (Exception e)
            {
                Logger.Error("Oracle Delete query failed " + e.Message);
                throw;
            }
        }
        /// <summary>
        /// Executes delete SQL command
        /// </summary>
        /// <param name="connection">SQLConnection</param>
        /// <param name="query">Delete query</param>
        /// <returns>true after deletion</returns>
        public bool SqlDeleteQuery(SqlConnection connection, string query)
        {
            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.InsertCommand = new SqlCommand(query, connection); ;
                adapter.InsertCommand.ExecuteNonQuery();
                adapter.Dispose();
                Logger.Info("Successfully executed SQL delete query");
                return true;
            }
            catch (Exception e)
            {
                Logger.Error("SQL delete query failed due to " + e.Message);
                throw;
            }
        }
        /// <summary>
        /// Executes Get SQL command
        /// </summary>
        /// <param name="connection">SQLConnection</param>
        /// <param name="query">Get query</param>
        /// <returns>DataTable</returns>
        private DataTable SqlGetQuery(SqlConnection connection, string query)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    SqlDataReader dataReader = cmd.ExecuteReader();
                    var dataTable = new DataTable();
                    dataTable.Load(dataReader);
                    Logger.Info("Successfully executed SQL get query");
                    return dataTable;
                }
            }
            catch (Exception e)
            {
                Logger.Error("Failed to execute SQL get query " + e.Message);
                throw;
            }
        }
        /// <summary>
        /// Executes Get Oracle command
        /// </summary>
        /// <param name="connection">OracleConnection</param>
        /// <param name="query">Get query</param>
        /// <returns>DataTable</returns>
        private DataTable OracleGetQuery(OracleConnection connection, string query)
        {
            try
            {
                using (OracleCommand cmd = new OracleCommand(query, connection))
                {
                    OracleDataReader dataReader = cmd.ExecuteReader();
                    var dataTable = new DataTable();
                    dataTable.Load(dataReader);
                    Logger.Info("Successfully executed Oracle get query");
                    return dataTable;
                }
            }
            catch (Exception e)
            {
                Logger.Error("Failed to execute Oracle get query due to " + e.Message);
                throw;
            }

        }
        /// <summary>
        /// Executes Insert Oracle command
        /// </summary>
        /// <param name="connection">OracleConnection</param>
        /// <param name="query">Insert query</param>
        /// <returns>true after successful inser query</returns>
        private bool OracleInsertQuery(OracleConnection connection, string query)
        {
            try
            {
                OracleDataAdapter adapter = new OracleDataAdapter();
                adapter.InsertCommand = new OracleCommand(query, connection);
                adapter.InsertCommand.ExecuteNonQuery();
                adapter.Dispose();
                Logger.Info("Successfully executed Oracle Insert query");
                return true;
            }
            catch (Exception e)
            {
                Logger.Error("Failed to execute oracle insert query due to " + e.Message);
                throw;
            }
        }
        /// <summary>
        /// Executes Insert SQL command
        /// </summary>
        /// <param name="connection">SQLConnection</param>
        /// <param name="query">Insert query</param>
        /// <returns>true after successful inser query</returns>
        public bool SqlInsertQuery(SqlConnection connection, string query)
        {
            //SqlCommand cmd = new SqlCommand(query, connection);
            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.InsertCommand = new SqlCommand(query, connection); ;
                adapter.InsertCommand.ExecuteNonQuery();
                adapter.Dispose();
                Logger.Info("Successfully executed SQL Insert query");
                return true;
            }
            catch (Exception e)
            {
                Logger.Error("Failed to execute insert query due to " + e.Message);
                throw;
            }
        }
        /// <summary>
        /// Get stored procedure 
        /// </summary>
        /// <param name="connection">SQLConnection</param>
        /// <param name="nameOfProcedure">procedure name</param>
        /// <returns>DataTable</returns>
        private DataTable GetSqlStoredProcedure(SqlConnection conn, string nameOfProcedure)
        {
            try
            {
                using (SqlCommand sqlCommand = new SqlCommand(nameOfProcedure, conn))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    SqlDataReader dataReader;
                    dataReader = sqlCommand.ExecuteReader();
                    var dataTable = new DataTable();
                    dataTable.Load(dataReader);
                    Logger.Info("Successfully retrived SQL Stored procedure ");
                    return dataTable;
                }
            }
            catch (Exception e)
            {
                Logger.Error("failed to retrieve SQL strored procedure " + e.Message);
                throw;
            }
        }
        /// <summary>
        /// Get stored procedure 
        /// </summary>
        /// <param name="connection">OracleConnection</param>
        /// <param name="nameOfProcedure">procedure name</param>
        /// <returns>DataTable</returns>
        private DataTable GetOracleStoredProcedure(OracleConnection conn, string nameOfProcedure)
        {
            try
            {
                using (OracleCommand command = new OracleCommand(nameOfProcedure, conn))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    OracleDataReader dataReader;
                    dataReader = command.ExecuteReader();
                    var dataTable = new DataTable();
                    dataTable.Load(dataReader);
                    Logger.Info("Successfully retrived oracle Stored procedure ");
                    return dataTable;
                }
            }
            catch (Exception e)
            {
                Logger.Error("Failed to retrieve oracle stored procedure due to " + e.Message);
                throw;
            }
        }
        //private bool ClosePostgreConnection(NpgsqlConnection connection)
        //{
        //    connection.Dispose();
        //    connection.Close();
        //    return true;
        //}

        //public DataTable RunGetQuery(NpgsqlConnection connection, string query)
        //{

        //    using (NpgsqlCommand i = new NpgsqlCommand(query, connection))
        //    {
        //       NpgsqlDataReader dataReader = i.ExecuteReader();
        //       var dataTable = new DataTable();
        //       dataTable.Load(dataReader);
        //        return dataTable;
        //    }

        //}
    }
}
