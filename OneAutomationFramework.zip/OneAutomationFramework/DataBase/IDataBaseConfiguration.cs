﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace OneAutomationFramework.DataBase
{
    public interface IDataBaseConfiguration
    {
        string dbType { get; }
        string connectionType { get; }
         string dataSource { get; }
         string database { get; }
        string connectionString { get; }
        string userName { get; }
        string password { get; }
        float defaultTimeout { get; }
        string optionalParameter { get; }
        string port { get; }
        string sid { get; }
        bool dataSourceDescriptor { get; }
    }
    public class DBConfiguration : IDataBaseConfiguration
    {
        private class SpecFlowActionJson
        {
            [JsonInclude]
            public DBSpecFlowJsonPart DatabaseConfiguration { get; private set; } = new DBSpecFlowJsonPart();
           
        }
        private class DBSpecFlowJsonPart
        {
            [JsonInclude]
            public string dbType { get; private set; }

            [JsonInclude]
            public string connectionType { get; private set; }

            [JsonInclude]
            public string database { get; private set; }
            [JsonInclude]
            public string dataSource { get; private set; }
            [JsonInclude]
            public string connectionString { get; private set; }
            [JsonInclude]
            public string userName { get; private set; }
            [JsonInclude]
           public string password { get; private set; }
            [JsonInclude]
            public float defaultTimeout { get; private set; }
            [JsonInclude]
            public string optionalParameter { get; private set; }
            [JsonInclude]
            public string port { get; private set; }
            [JsonInclude]
            public string sid { get; private set; }
            [JsonInclude]
            public bool dataSourceDescriptor { get; private set; }

        }
        private readonly Lazy<SpecFlowActionJson> _specflowJsonPart;

        private SpecFlowActionJson LoadSpecFlowJson()
        {
            var json = Load();

            if (string.IsNullOrWhiteSpace(json))
            {
                return new SpecFlowActionJson();
            }

            var jsonSerializerOptions = new JsonSerializerOptions()
            {
                PropertyNameCaseInsensitive = true
            };

            jsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());

            var specflowActionConfig = System.Text.Json.JsonSerializer.Deserialize<SpecFlowActionJson>(json, jsonSerializerOptions);

            return specflowActionConfig ?? new SpecFlowActionJson();
        }
        /// <summary>
        /// Provides the configuration details for the DB
        /// </summary>
        /// <param name="specFlowActionJsonLoader"></param>
        public DBConfiguration()
        {
            _specflowJsonPart = new Lazy<SpecFlowActionJson>(LoadSpecFlowJson);
        }
        /// <summary>
        /// Connection string specified in configuration
        /// </summary>
        ///
        public string connectionType => _specflowJsonPart.Value.DatabaseConfiguration.connectionType;
        public string dbType => _specflowJsonPart.Value.DatabaseConfiguration.dbType;
        public string dataSource => _specflowJsonPart.Value.DatabaseConfiguration.dataSource;
        public string connectionString => _specflowJsonPart.Value.DatabaseConfiguration.connectionString;
        public string userName => _specflowJsonPart.Value.DatabaseConfiguration.userName;
        public string password => _specflowJsonPart.Value.DatabaseConfiguration.password;
        public float defaultTimeout => _specflowJsonPart.Value.DatabaseConfiguration.defaultTimeout;
        public string optionalParameter => _specflowJsonPart.Value.DatabaseConfiguration.optionalParameter;
        public string database => _specflowJsonPart.Value.DatabaseConfiguration.database;
        public string port => _specflowJsonPart.Value.DatabaseConfiguration.port;
        public string sid => _specflowJsonPart.Value.DatabaseConfiguration.sid;
        public bool dataSourceDescriptor => _specflowJsonPart.Value.DatabaseConfiguration.dataSourceDescriptor;
        private string? GetFilePathToConfigurationFile(string configurationFileName)
        {
            if (AppDomain.CurrentDomain.BaseDirectory is not null)
            {
                var specflowJsonFileInAppDomainBaseDirectory =
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, configurationFileName);

                if (File.Exists(specflowJsonFileInAppDomainBaseDirectory))
                {
                    return specflowJsonFileInAppDomainBaseDirectory;
                }

                var specflowJsonFileTwoDirectoriesUp =
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", configurationFileName);

                if (File.Exists(specflowJsonFileTwoDirectoriesUp))
                {
                    return specflowJsonFileTwoDirectoriesUp;
                }
            }

            var specflowJsonFileInCurrentDirectory = Path.Combine(Environment.CurrentDirectory, configurationFileName);

            if (File.Exists(specflowJsonFileInCurrentDirectory))
            {
                return specflowJsonFileInCurrentDirectory;
            }

            return null;
        }

        public string Load()
        {
            var specFlowJsonFilePath = GetFilePathToConfigurationFile("DatabaseConfig.json");

            if (specFlowJsonFilePath != null)
            {
                var content = File.ReadAllText(specFlowJsonFilePath);

                return content;
            }

            return "{}";
        }

        public dynamic LoadJson()
        {
            var specFlowJsonFilePath = GetFilePathToConfigurationFile("DatabaseConfig.json");
            var content = File.ReadAllText(specFlowJsonFilePath);
            return JsonConvert.DeserializeObject(content);

        }
    }

}